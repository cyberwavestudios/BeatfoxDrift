import { useEffect, useRef, useState } from 'react';
import GameCanvas from './GameCanvas';
import { TouchControls } from './TouchControls';
import { useGameState } from '../lib/stores/useGameState';
import { useAudio, SOUNDTRACK_TRACKS, SECRET_TRACK } from '../lib/stores/useAudio';

// Crystal color sequence: Blue → Yellow → Purple → Orange → Pink → Red → Green
const CRYSTAL_COLORS = [
  { name: 'Blue', hex: '#00ffff', glow: 'rgba(0, 255, 255, 0.8)' },
  { name: 'Yellow', hex: '#ffff00', glow: 'rgba(255, 255, 0, 0.8)' },
  { name: 'Purple', hex: '#aa00ff', glow: 'rgba(170, 0, 255, 0.8)' },
  { name: 'Orange', hex: '#ff8800', glow: 'rgba(255, 136, 0, 0.8)' },
  { name: 'Pink', hex: '#ff00aa', glow: 'rgba(255, 0, 170, 0.8)' },
  { name: 'Red', hex: '#ff0044', glow: 'rgba(255, 0, 68, 0.8)' },
  { name: 'Green', hex: '#00ff44', glow: 'rgba(0, 255, 68, 0.8)' }
];

// Optimized color functions with memoization
const getCrystalColor = (count: number) => {
  const index = Math.min(count, CRYSTAL_COLORS.length - 1);
  return CRYSTAL_COLORS[index];
};

const getCollectedCrystalColor = (count: number) => {
  const index = Math.min(Math.max(count - 1, 0), CRYSTAL_COLORS.length - 1);
  return CRYSTAL_COLORS[index];
};

const Game = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { score, highScore, isPlaying, gamePhase, cyberCrystals, isInSecretLevel } = useGameState();
  const { toggleMute, isMuted, getCurrentSector } = useAudio();
  const [showInstructions, setShowInstructions] = useState(true);
  const [showDownloads, setShowDownloads] = useState(false);
  const [showSoundNotification, setShowSoundNotification] = useState(false);
  const [showCrystalAnimation, setShowCrystalAnimation] = useState(false);
  const [lastCrystalCount, setLastCrystalCount] = useState(0); // Always start from 0
  const [crystalAnimationColors, setCrystalAnimationColors] = useState({ hex: '#00ffff', glow: 'rgba(0, 255, 255, 0.8)' });
  
  // The self-hosted edition is open to everyone. Keep game progression intact.
  const hasAccess = true;

  // Get current space sector from the music system
  const currentSector = getCurrentSector();
  
  // Handle crystal collection animation with optimized color caching
  useEffect(() => {
    if (cyberCrystals > lastCrystalCount) {
      // Cache colors to avoid recalculation during animation
      const colors = getCollectedCrystalColor(cyberCrystals);
      setCrystalAnimationColors(colors);
      setShowCrystalAnimation(true);
      setLastCrystalCount(cyberCrystals);
      
      // Hide animation after 2 seconds
      const timer = setTimeout(() => setShowCrystalAnimation(false), 2000);
      return () => clearTimeout(timer);
    }
  }, [cyberCrystals, lastCrystalCount]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'KeyM') {
        toggleMute();
      }
    };

    // Prevent touch scrolling globally, but allow button interactions
    const preventTouchScroll = (e: TouchEvent) => {
      const target = e.target as Element;
      // Allow touches on buttons, inputs, and interactive elements
      if (target && (
        target.tagName === 'BUTTON' ||
        target.tagName === 'INPUT' ||
        target.tagName === 'SELECT' ||
        target.tagName === 'TEXTAREA' ||
        target.closest('button') ||
        target.closest('.start-button') ||
        target.closest('.downloads-button') ||
        target.closest('.download-item') ||
        target.closest('.instructions-overlay') ||
        target.closest('.downloads-overlay')
      )) {
        return; // Allow default behavior for interactive elements
      }
      e.preventDefault();
    };

    window.addEventListener('keydown', handleKeyDown);
    
    // Add selective touch prevention with passive: false
    document.addEventListener('touchstart', preventTouchScroll, { passive: false });
    document.addEventListener('touchmove', preventTouchScroll, { passive: false });
    document.addEventListener('touchend', preventTouchScroll, { passive: false });
    
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.removeEventListener('touchstart', preventTouchScroll);
      document.removeEventListener('touchmove', preventTouchScroll);
      document.removeEventListener('touchend', preventTouchScroll);
    };
  }, [toggleMute]);

  const handleStartGame = () => {
    const { start } = useGameState.getState();
    const audioState = useAudio.getState();
    
    setShowInstructions(false);
    setShowDownloads(false);
    
    // Show sound notification on mobile devices
    const isMobile = window.innerWidth <= 768 || /Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    if (isMobile) {
      setShowSoundNotification(true);
      // Hide notification after 3 seconds
      setTimeout(() => setShowSoundNotification(false), 3000);
    }
    
    // CRITICAL: Force audio to play on user interaction for iOS
    if (audioState.currentTrack) {
      audioState.currentTrack.volume = 0.4;
      audioState.currentTrack.play().catch(error => {
        console.log("iOS audio play attempt:", error);
      });
      console.log('🔊 Forcing audio play on user interaction');
    }
    
    // Auto-enable sound when user starts the game
    if (isMuted) {
      toggleMute();
    }
    start(); // Actually start the game when user clicks
  };

  const handleDownloadSong = (filename: string, trackName: string) => {
    const link = document.createElement('a');
    link.href = filename;
    link.download = `${trackName.replace(/[^a-zA-Z0-9]/g, '_')}.mp3`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleGoToSecretLevel = () => {
    if (canvasRef.current) {
      const gameEngine = (canvasRef.current as any).gameEngine;
      if (gameEngine && cyberCrystals >= 7 && !isInSecretLevel) {
        gameEngine.triggerSecretLevel();
      }
    }
  };

  const allTracks = [...SOUNDTRACK_TRACKS, SECRET_TRACK];

  // Remove auto-start - user must click to start
  // Game will only start when user clicks the start button

  return (
    <div className="game-container">
      {/* Orientation lock overlay for mobile landscape mode */}
      <div className="orientation-overlay">
        <div className="orientation-icon">📱</div>
        <div className="orientation-message">Please rotate your device</div>
        <div className="orientation-subtitle">Beatfox Drift works best in portrait mode</div>
      </div>
      
      {/* Sound notification for mobile users */}
      {showSoundNotification && (
        <div className="sound-notification">
          <span className="sound-notification-icon">🔊</span>
          Sound On!
        </div>
      )}
      
      {/* Crystal collection animation */}
      {showCrystalAnimation && (
        <div className="crystal-animation">
          <div 
            className="crystal-burst"
            style={{
              '--crystal-color': crystalAnimationColors.hex,
              '--crystal-glow': crystalAnimationColors.glow,
              border: `3px solid ${crystalAnimationColors.hex}`,
              boxShadow: `0 0 30px ${crystalAnimationColors.glow}`
            } as React.CSSProperties}
          >
            <span 
              className="crystal-large"
              style={{ color: crystalAnimationColors.hex }}
            >
              ◆
            </span>
            <div 
              className="crystal-text"
              style={{ 
                color: crystalAnimationColors.hex,
                textShadow: `0 0 10px ${crystalAnimationColors.glow}`
              }}
            >
              CYBER-CRYSTAL ACQUIRED!
            </div>
            <div className="crystal-progress">{cyberCrystals}/7</div>
            {cyberCrystals === 7 && (
              <div className="secret-unlock">🌟 SECRET LEVEL UNLOCKED! 🌟</div>
            )}
          </div>
        </div>
      )}
      <div className="game-ui">
        <div className="score-display">
          <div className="current-score">Score: {score}</div>
          <div className="high-score">High Score: {highScore}</div>
          <div className="crystal-display">
            <span 
              className="crystal-icon"
              style={{
                color: getCrystalColor(cyberCrystals).hex,
                textShadow: `0 0 8px ${getCrystalColor(cyberCrystals).glow}`,
                fontSize: '16px'
              }}
            >
              ◆
            </span>
            <span 
              className="crystal-count"
              style={{ 
                color: getCrystalColor(cyberCrystals).hex,
                textShadow: `2px 2px 0px rgba(0, 0, 0, 0.8), 0 0 8px ${getCrystalColor(cyberCrystals).glow}`
              }}
            >
              {cyberCrystals}/7
            </span>
            {cyberCrystals >= 7 && !isInSecretLevel && (
              <button 
                className="secret-button"
                onClick={handleGoToSecretLevel}
              >
                GO TO SECRET SECTOR
              </button>
            )}
          </div>
          <div className="sector-info" style={{ color: currentSector.color }}>
            {isInSecretLevel ? '🌟 SECRET: Nebula Collapse' : `Sector: ${currentSector.name}`}
          </div>
        </div>
        
        <div className="controls-info desktop-only">
          <div>Arrow Keys / WASD: Move</div>
          <div>M: Toggle Sound ({isMuted ? 'OFF' : 'ON'})</div>
        </div>
      </div>

      {hasAccess && showInstructions && gamePhase === 'ready' && (
        <div className="instructions-overlay">
          <div className="instructions-panel">
            <h1>BEATFOX DRIFT</h1>
            <div className="instructions-text">
              <p>Guide Beatfox through the Cyber-verse!</p>
              <p>• Use Arrow Keys or WASD to move</p>
              <p>• Avoid the white timeline obstacles</p>
              <p>• Journey through different cyber sectors driven by music:</p>
              <p style={{ fontSize: '12px', color: '#aaa', marginLeft: '10px' }}>
                Resistance Nebula • Toxic Clouds • Misty Void • Memory Fields<br/>
                Digital Economy • War Zone • Crystal Depths • Star Memorial<br/>
                Paradise Lost • Phase Shifter • Sync Matrix • Terminal Station • Pressure Zone
              </p>
              <p style={{ fontSize: '14px', color: '#ff8800', marginTop: '10px' }}>
                🎯 Collect all 7 cyber-crystals and beat the secret sector for a surprise message!
              </p>
            </div>
            <div className="menu-buttons">
              <button 
                className="start-button"
                onClick={handleStartGame}
              >
                START DRIFTING
              </button>
              <button 
                className="downloads-button"
                onClick={() => setShowDownloads(true)}
              >
                DOWNLOAD SONGS
              </button>
            </div>
          </div>
        </div>
      )}

      {hasAccess && showDownloads && (
        <div className="downloads-overlay">
          <div className="downloads-panel">
            <h1>DOWNLOAD SOUNDTRACK</h1>
            <div className="downloads-header">
              <p>Free royalty-free music downloads with unlimited use license</p>
              <p style={{ fontSize: '12px', color: '#aaa' }}>All tracks are provided under a royalty-free unlimited use license</p>
            </div>
            <div className="downloads-list">
              {allTracks.map((track, index) => (
                <div key={index} className="download-item">
                  <div className="track-info">
                    <div className="track-name">{track.sector}</div>
                    <div className="track-filename" style={{ color: track.color }}>
                      {track.file.split('/').pop()}
                    </div>
                  </div>
                  <button 
                    className="download-btn"
                    onClick={() => handleDownloadSong(track.file, track.sector)}
                  >
                    DOWNLOAD
                  </button>
                </div>
              ))}
            </div>
            <div className="downloads-footer">
              <button 
                className="back-button"
                onClick={() => setShowDownloads(false)}
              >
                BACK TO MENU
              </button>
            </div>
          </div>
        </div>
      )}

      <GameCanvas ref={canvasRef} />
      <TouchControls onMove={(deltaX, deltaY) => {
        if (canvasRef.current) {
          const gameEngine = (canvasRef.current as any).gameEngine;
          if (gameEngine && !gameEngine.isOrientationBlocked()) {
            gameEngine.setTouchMovement(deltaX, deltaY);
          }
        }
      }} />
    </div>
  );
};

export default Game;
