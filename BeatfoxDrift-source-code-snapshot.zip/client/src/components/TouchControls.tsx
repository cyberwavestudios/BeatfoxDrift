import React, { useEffect, useRef, useState, useCallback } from 'react';

interface TouchControlsProps {
  onMove: (deltaX: number, deltaY: number) => void;
}

interface TouchData {
  x: number;
  y: number;
  centerX: number;
  centerY: number;
  isActive: boolean;
}

export const TouchControls: React.FC<TouchControlsProps> = ({ onMove }) => {
  const joystickRef = useRef<HTMLDivElement>(null);
  const knobRef = useRef<HTMLDivElement>(null);
  const [touchData, setTouchData] = useState<TouchData>({
    x: 0,
    y: 0,
    centerX: 0,
    centerY: 0,
    isActive: false
  });

  // Check if device supports touch
  const isTouchDevice = 'ontouchstart' in window || navigator.maxTouchPoints > 0;

  const handleTouchStart = useCallback((e: React.TouchEvent | TouchEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const touch = 'touches' in e ? e.touches[0] : (e as any).touches[0];
    const rect = joystickRef.current?.getBoundingClientRect();
    if (!rect) return;

    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    setTouchData({
      x: touch.clientX,
      y: touch.clientY,
      centerX,
      centerY,
      isActive: true
    });
  }, []);

  const handleTouchMove = useCallback((e: React.TouchEvent | TouchEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (!touchData.isActive) return;

    const touch = 'touches' in e ? e.touches[0] : (e as any).touches[0];
    const deltaX = touch.clientX - touchData.centerX;
    const deltaY = touch.clientY - touchData.centerY;
    
    // Limit movement to joystick radius
    const maxDistance = 40;
    const distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
    
    let normalizedX = deltaX;
    let normalizedY = deltaY;
    
    if (distance > maxDistance) {
      normalizedX = (deltaX / distance) * maxDistance;
      normalizedY = (deltaY / distance) * maxDistance;
    }

    // Update knob position
    if (knobRef.current) {
      knobRef.current.style.transform = `translate(${normalizedX}px, ${normalizedY}px)`;
    }

    // Calculate movement intensity (-1 to 1)
    const moveX = normalizedX / maxDistance;
    const moveY = normalizedY / maxDistance;
    
    // Send movement to game with minimal sensitivity for maximum precision
    onMove(moveX * 1.5, moveY * 1.5); // Minimal sensitivity for exhaustive precision control
  }, [touchData, onMove]);

  const handleTouchEnd = useCallback((e: React.TouchEvent | TouchEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setTouchData(prev => ({ ...prev, isActive: false }));
    
    // Reset knob position
    if (knobRef.current) {
      knobRef.current.style.transform = 'translate(0px, 0px)';
    }
    
    // Stop movement
    onMove(0, 0);
  }, [onMove]);

  // Add passive: false event listeners to prevent default scrolling
  useEffect(() => {
    const joystick = joystickRef.current;
    if (!joystick) return;

    const handleTouchStartNative = (e: TouchEvent) => {
      e.preventDefault();
      e.stopPropagation();
      handleTouchStart(e as any);
    };

    const handleTouchMoveNative = (e: TouchEvent) => {
      e.preventDefault();
      e.stopPropagation();
      handleTouchMove(e as any);
    };

    const handleTouchEndNative = (e: TouchEvent) => {
      e.preventDefault();
      e.stopPropagation();
      handleTouchEnd(e as any);
    };

    joystick.addEventListener('touchstart', handleTouchStartNative, { passive: false });
    joystick.addEventListener('touchmove', handleTouchMoveNative, { passive: false });
    joystick.addEventListener('touchend', handleTouchEndNative, { passive: false });

    return () => {
      joystick.removeEventListener('touchstart', handleTouchStartNative);
      joystick.removeEventListener('touchmove', handleTouchMoveNative);
      joystick.removeEventListener('touchend', handleTouchEndNative);
    };
  }, [handleTouchStart, handleTouchMove, handleTouchEnd]);

  // Don't render on non-touch devices
  if (!isTouchDevice) {
    return null;
  }

  return (
    <div className="touch-controls">
      <div
        ref={joystickRef}
        className="joystick"
        style={{
          position: 'fixed',
          bottom: '40px',
          right: '40px',
          width: '120px',
          height: '120px',
          borderRadius: '50%',
          background: 'rgba(255, 255, 255, 0.1)',
          border: '2px solid rgba(255, 255, 255, 0.3)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000,
          userSelect: 'none',
          touchAction: 'none'
        }}
      >
        <div
          ref={knobRef}
          className="joystick-knob"
          style={{
            width: '50px',
            height: '50px',
            borderRadius: '50%',
            background: 'rgba(255, 255, 255, 0.8)',
            border: '2px solid rgba(255, 255, 255, 1)',
            transition: touchData.isActive ? 'none' : 'transform 0.2s ease',
            boxShadow: '0 0 10px rgba(255, 255, 255, 0.5)'
          }}
        />
      </div>
    </div>
  );
};