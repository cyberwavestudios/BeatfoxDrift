import { forwardRef, useEffect, useRef } from 'react';
import { GameEngine } from '../lib/gameEngine';

interface GameCanvasProps {
  className?: string;
}

const GameCanvas = forwardRef<HTMLCanvasElement, GameCanvasProps>(
  ({ className }, ref) => {
    const internalRef = useRef<HTMLCanvasElement>(null);
    const gameEngineRef = useRef<GameEngine | null>(null);

    useEffect(() => {
      const canvas = (ref as React.RefObject<HTMLCanvasElement>)?.current || internalRef.current;
      if (!canvas) return;

      // Set up canvas for pixel art
      const ctx = canvas.getContext('2d')!;
      ctx.imageSmoothingEnabled = false;
      
      // Set canvas size with robust mobile browser support
      const resizeCanvas = () => {
        try {
          const rect = canvas.getBoundingClientRect();
          
          // Mobile browsers fix: Retry if dimensions are invalid
          if (rect.width === 0 || rect.height === 0) {
            console.warn('Canvas getBoundingClientRect returned 0 dimensions, retrying...');
            
            // Force a layout update and retry
            canvas.style.display = 'none';
            canvas.offsetHeight; // Force reflow
            canvas.style.display = 'block';
            
            // Wait a frame and retry
            requestAnimationFrame(() => {
              const retryRect = canvas.getBoundingClientRect();
              if (retryRect.width > 0 && retryRect.height > 0) {
                setCanvasDimensions(retryRect);
              } else {
                // Use fallback dimensions
                const fallbackWidth = Math.min(window.innerWidth * 0.9, 800);
                const fallbackHeight = Math.min(window.innerHeight * 0.7, 600);
                setCanvasDimensions({ width: fallbackWidth, height: fallbackHeight });
                console.log('Using fallback dimensions:', fallbackWidth, 'x', fallbackHeight);
              }
            });
            return;
          }
          
          setCanvasDimensions(rect);
          
        } catch (error) {
          console.warn('Canvas getBoundingClientRect failed, using viewport dimensions');
          const fallbackWidth = Math.min(window.innerWidth * 0.9, 800);
          const fallbackHeight = Math.min(window.innerHeight * 0.7, 600);
          setCanvasDimensions({ width: fallbackWidth, height: fallbackHeight });
          console.log('Fallback dimensions:', fallbackWidth, 'x', fallbackHeight);
        }
      };
      
      // Helper function to set canvas dimensions consistently
      const setCanvasDimensions = (rect: { width: number; height: number }) => {
        // Set CSS size first for Safari iOS
        canvas.style.width = `${rect.width}px`;
        canvas.style.height = `${rect.height}px`;
        
        // For Safari iOS, avoid high pixel ratios that cause distortion
        const isSafariIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && (window as any).safari !== undefined;
        const pixelRatio = isSafariIOS ? Math.min(window.devicePixelRatio || 1, 2) : (window.devicePixelRatio || 1);
        
        // Set actual canvas resolution
        canvas.width = rect.width * pixelRatio;
        canvas.height = rect.height * pixelRatio;
        
        // Scale context for crisp rendering
        ctx.resetTransform(); // Clear any existing transforms
        ctx.scale(pixelRatio, pixelRatio);
        ctx.imageSmoothingEnabled = false;
        
        // Notify game engine of dimension change
        if (gameEngineRef.current) {
          gameEngineRef.current.handleResize();
        }
        
        console.log('Canvas resized to:', rect.width + 'x' + rect.height);
        console.log('Final game dimensions:', rect.width, 'x', rect.height);
      };

      // Mobile browsers: Wait for DOM to settle before initializing
      const initializeGame = () => {
        // Initial resize with delay for mobile browsers
        setTimeout(() => {
          resizeCanvas();
          
          // Initialize game engine after canvas is properly sized
          setTimeout(() => {
            gameEngineRef.current = new GameEngine(canvas);
            (canvas as any).gameEngine = gameEngineRef.current;
            gameEngineRef.current.start();
          }, 100);
        }, 50);
      };
      
      window.addEventListener('resize', resizeCanvas);

      // Prevent touch scrolling on canvas specifically (only during gameplay)
      const preventCanvasTouch = (e: TouchEvent) => {
        // Only prevent touch events when actually on the canvas area
        const rect = canvas.getBoundingClientRect();
        const touch = e.touches[0] || (e as any).changedTouches?.[0];
        
        if (touch && 
            touch.clientX >= rect.left && 
            touch.clientX <= rect.right && 
            touch.clientY >= rect.top && 
            touch.clientY <= rect.bottom) {
          e.preventDefault();
          e.stopPropagation();
        }
      };

      canvas.addEventListener('touchstart', preventCanvasTouch, { passive: false });
      canvas.addEventListener('touchmove', preventCanvasTouch, { passive: false });
      canvas.addEventListener('touchend', preventCanvasTouch, { passive: false });

      // Initialize the game with proper timing
      initializeGame();

      return () => {
        window.removeEventListener('resize', resizeCanvas);
        canvas.removeEventListener('touchstart', preventCanvasTouch);
        canvas.removeEventListener('touchmove', preventCanvasTouch);
        canvas.removeEventListener('touchend', preventCanvasTouch);
        gameEngineRef.current?.destroy();
        gameEngineRef.current = null;
      };
    }, [ref]);

    return (
      <canvas
        ref={(ref as React.RefObject<HTMLCanvasElement>) || internalRef}
        className={`game-canvas ${className || ''}`}
      />
    );
  }
);

GameCanvas.displayName = 'GameCanvas';

export default GameCanvas;
