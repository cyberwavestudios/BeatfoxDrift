import { useEffect } from 'react';
import Game from './components/Game';
import { useAudio } from './lib/stores/useAudio';
import "./index.css";

function App() {
  const { initializeSoundtrack, setHitSound, setSuccessSound } = useAudio();

  useEffect(() => {
    // Load sound effects
    const hitSound = new Audio('/sounds/hit.mp3');
    const successSound = new Audio('/sounds/success.mp3');

    setHitSound(hitSound);
    setSuccessSound(successSound);
    
    // Initialize the soundtrack system
    initializeSoundtrack();
  }, [setHitSound, setSuccessSound, initializeSoundtrack]);

  return (
    <div className="app">
      <Game />
    </div>
  );
}

export default App;
