interface TimelineObstacle {
  x: number;
  y: number;
  width: number;
  height: number;
  speed: number;
  glowPhase: number;
  type: 'vertical' | 'horizontal' | 'diagonal' | 'moving';
  angle?: number; // For diagonal obstacles
  verticalSpeed?: number; // For moving obstacles
  verticalDirection?: number; // 1 or -1 for up/down
}

export class ObstacleManager {
  private obstacles: TimelineObstacle[] = [];
  private canvasWidth: number;
  private canvasHeight: number;
  private spawnTimer: number = 0;
  private baseSpawnRate: number = 2000; // 2 seconds
  private isMobile: boolean;
  private initialSpawnTimeout: NodeJS.Timeout | null = null;
  private activeCount: number = 0;
  private isSecretLevel: boolean = false;
  
  // Pre-calculated constants for performance
  private readonly ONE_THOUSANDTH = 0.001;
  private readonly GLOW_MULTIPLIER = 0.008;

  constructor(canvasWidth: number, canvasHeight: number) {
    this.canvasWidth = canvasWidth;
    this.canvasHeight = canvasHeight;
    
    // Detect mobile device
    this.isMobile = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
    
    // Spawn initial obstacle immediately for testing
    this.initialSpawnTimeout = setTimeout(() => this.spawnObstacle(0), 500);
  }

  update(deltaTime: number, difficultyLevel: number = 0, score: number = 0) {
    this.spawnTimer += deltaTime;
    
    // Progressive spawn rate scaling based on score
    const spawnRateMultiplier = Math.min(score / 300, 2.0); // Faster spawning at higher scores
    const baseRate = this.baseSpawnRate - difficultyLevel * 100;
    const spawnRate = Math.max(800, baseRate - (spawnRateMultiplier * 600)); // Minimum 0.8s between spawns
    
    if (this.spawnTimer >= spawnRate) {
      this.spawnObstacle(score);
      this.spawnTimer = 0;
    }

    // Update existing obstacles with efficient array management
    const dt = deltaTime * this.ONE_THOUSANDTH;
    let writeIndex = 0;
    
    for (let i = 0; i < this.activeCount; i++) {
      const obstacle = this.obstacles[i];
      
      obstacle.x -= obstacle.speed * dt;
      obstacle.glowPhase += deltaTime * this.GLOW_MULTIPLIER;
      
      // Handle moving obstacles (secret level)
      if (obstacle.type === 'moving' && obstacle.verticalSpeed && obstacle.verticalDirection) {
        obstacle.y += obstacle.verticalSpeed * obstacle.verticalDirection * dt;
        
        // Bounce off top and bottom
        if (obstacle.y <= 20) {
          obstacle.y = 20;
          obstacle.verticalDirection = 1; // Move down
        } else if (obstacle.y >= this.canvasHeight - obstacle.height - 20) {
          obstacle.y = this.canvasHeight - obstacle.height - 20;
          obstacle.verticalDirection = -1; // Move up
        }
      }
      
      // Keep obstacles that are still on-screen
      if (obstacle.x + obstacle.width >= -50) {
        this.obstacles[writeIndex++] = obstacle;
      }
    }
    
    this.activeCount = writeIndex;
  }

  private spawnObstacle(score: number = 0) {
    let obstacleType: 'vertical' | 'horizontal' | 'diagonal' | 'moving';
    
    // Calculate progressive difficulty multipliers (more aggressive scaling)
    const difficultyFactor = Math.min(score / 300, 3.0); // Faster scaling, noticeable at 300 points
    const speedMultiplier = 1.0 + (difficultyFactor * 0.8); // 80% speed increase at max (2.4x at 900+ score)
    const thicknessMultiplier = 1.0 + (difficultyFactor * 0.6); // 60% thickness increase at max (1.8x at 900+ score)
    
    if (this.isSecretLevel) {
      // Secret level: Only spawn moving obstacles
      obstacleType = 'moving';
    } else {
      // Normal distribution: More horizontal, fewer vertical, diagonal from start
      const rand = Math.random();
      if (rand < 0.2) obstacleType = 'vertical';         // 20% vertical (reduced)
      else if (rand < 0.65) obstacleType = 'horizontal'; // 45% horizontal (increased)
      else obstacleType = 'diagonal';                    // 35% diagonal (new)
    }
    
    if (obstacleType === 'vertical') {
      // Vertical timeline obstacles
      const height = 80 + Math.random() * 140;
      const y = Math.random() * (this.canvasHeight - height - 40) + 20;
      
      // Reduce length on mobile for better playability
      const mobileFactor = this.isMobile ? 0.8 : 1.8;
      
      this.obstacles[this.activeCount++] = {
        x: this.canvasWidth + 20,
        y: y,
        width: Math.round(6 * thicknessMultiplier),
        height: Math.max(120, height * mobileFactor), // Shorter on mobile
        speed: (120 + Math.random() * 80) * speedMultiplier,
        glowPhase: Math.random() * Math.PI * 2,
        type: 'vertical'
      };
    } else if (obstacleType === 'horizontal') {
      // Horizontal timeline obstacles - slightly longer on mobile for balance
      const baseWidth = this.isMobile ? 200 : 250; // Slightly longer base on mobile
      const extraWidth = this.isMobile ? 250 : 400; // Moderate extra width on mobile
      const width = baseWidth + Math.random() * extraWidth;
      const x = this.canvasWidth + 20;
      const y = Math.random() * (this.canvasHeight - 40) + 20;
      
      this.obstacles[this.activeCount++] = {
        x: x,
        y: y,
        width: width, // Shorter obstacles on mobile
        height: Math.round(6 * thicknessMultiplier),
        speed: (100 + Math.random() * 60) * speedMultiplier,
        glowPhase: Math.random() * Math.PI * 2,
        type: 'horizontal'
      };
    } else if (obstacleType === 'diagonal') {
      // Diagonal timeline obstacles - start with 45 degrees, get more random as score increases
      let angle;
      if (score < 200) {
        // Start with clean 45-degree angles
        angle = Math.random() < 0.5 ? 45 : -45;
      } else if (score < 400) {
        // Add more angle variations
        const angles = [30, 45, 60, -30, -45, -60];
        angle = angles[Math.floor(Math.random() * angles.length)];
      } else {
        // Full random angles (but avoid horizontal/vertical)
        angle = Math.random() * 120 - 60; // -60 to +60 degrees
        if (Math.abs(angle) < 15) {
          angle += angle >= 0 ? 15 : -15; // Safer than Math.sign for edge cases
        }
      }
      
      // Moderately reduce diagonal length on mobile
      const baseLength = this.isMobile ? 70 : 80;
      const extraLength = this.isMobile ? 50 : 60;
      const length = baseLength + Math.random() * extraLength;
      
      this.obstacles[this.activeCount++] = {
        x: this.canvasWidth + 20,
        y: Math.random() * (this.canvasHeight - 100) + 50,
        width: length, // Shorter diagonals on mobile
        height: Math.round(6 * thicknessMultiplier),
        speed: (110 + Math.random() * 70) * speedMultiplier,
        glowPhase: Math.random() * Math.PI * 2,
        type: 'diagonal',
        angle: angle
      };
    } else if (obstacleType === 'moving') {
      // Moving obstacles for secret level - much more challenging
      const length = 100 + Math.random() * 150;
      const startY = Math.random() * (this.canvasHeight - 100) + 50;
      
      this.obstacles[this.activeCount++] = {
        x: this.canvasWidth + 20,
        y: startY,
        width: length,
        height: Math.round(8 * thicknessMultiplier), // Thicker for secret level
        speed: (150 + Math.random() * 100) * speedMultiplier, // Faster
        glowPhase: Math.random() * Math.PI * 2,
        type: 'moving',
        verticalSpeed: 80 + Math.random() * 120, // Variable vertical movement speed
        verticalDirection: Math.random() < 0.5 ? 1 : -1 // Random initial direction
      };
    }
    
    // Remove console logging for performance in game loop
  }

  render(ctx: CanvasRenderingContext2D) {
    // Batch rendering optimizations
    ctx.fillStyle = '#ffffff';
    
    for (let i = 0; i < this.activeCount; i++) {
      const obstacle = this.obstacles[i];
      // Each timeline has its own unique pulse frequency
      const glowIntensity = 0.6 + Math.sin(obstacle.glowPhase) * 0.4;
      
      // Simplified glow effect for performance
      ctx.save();
      ctx.shadowColor = '#ffffff';
      ctx.shadowBlur = 15 * glowIntensity; // Reduced blur for performance
      
      if (obstacle.type === 'diagonal' && obstacle.angle !== undefined) {
        // Render diagonal obstacles with rotation
        ctx.translate(obstacle.x + obstacle.width / 2, obstacle.y + obstacle.height / 2);
        ctx.rotate((obstacle.angle * Math.PI) / 180);
        
        // Main diagonal line
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(-obstacle.width / 2, -obstacle.height / 2, obstacle.width, obstacle.height);
        
        // Glow layers
        ctx.fillStyle = `rgba(255, 255, 255, ${glowIntensity * 0.7})`;
        ctx.fillRect(-obstacle.width / 2 - 3, -obstacle.height / 2 - 2, obstacle.width + 6, obstacle.height + 4);
        
        ctx.fillStyle = `rgba(255, 255, 255, ${glowIntensity * 0.4})`;
        ctx.fillRect(-obstacle.width / 2 - 5, -obstacle.height / 2 - 4, obstacle.width + 10, obstacle.height + 8);
      } else {
        // Render vertical/horizontal obstacles normally
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(obstacle.x, obstacle.y, obstacle.width, obstacle.height);
        
        // Outer glow layers
        ctx.fillStyle = `rgba(255, 255, 255, ${glowIntensity * 0.7})`;
        ctx.fillRect(obstacle.x - 3, obstacle.y - 2, obstacle.width + 6, obstacle.height + 4);
        
        ctx.fillStyle = `rgba(255, 255, 255, ${glowIntensity * 0.4})`;
        ctx.fillRect(obstacle.x - 5, obstacle.y - 4, obstacle.width + 10, obstacle.height + 8);
      }
      
      ctx.restore();
      
      // Enhanced particle trail
      if (Math.random() < 0.5) {
        ctx.fillStyle = `rgba(255, 255, 255, ${Math.random() * 0.8})`;
        const trailX = obstacle.x + obstacle.width + Math.random() * 15;
        const trailY = obstacle.y + Math.random() * obstacle.height;
        const size = Math.random() < 0.3 ? 2 : 1;
        ctx.fillRect(trailX, trailY, size, size);
      }
    }
  }

  getObstacles(): TimelineObstacle[] {
    return this.obstacles.slice(0, this.activeCount);
  }

  setSecretLevel(enabled: boolean) {
    this.isSecretLevel = enabled;
    if (enabled) {
      // Clear existing obstacles when entering secret level
      this.activeCount = 0;
      this.spawnTimer = 0;
    }
  }
  
  reset() {
    this.activeCount = 0;
    this.spawnTimer = 0;
    this.isSecretLevel = false;
    
    // Clear any pending timeouts
    if (this.initialSpawnTimeout) {
      clearTimeout(this.initialSpawnTimeout);
      this.initialSpawnTimeout = null;
    }
  }

  destroy() {
    this.reset();
    // Additional cleanup if needed
  }
}
