interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  color: string;
  size: number;
  type: 'dash' | 'collision' | 'star';
  active: boolean;
}

export class ParticleSystem {
  private particles: Particle[] = [];
  private pool: Particle[] = [];
  private activeCount: number = 0;

  update(deltaTime: number) {
    const dt = deltaTime * 0.001; // Pre-calculate
    let writeIndex = 0;
    
    for (let i = 0; i < this.activeCount; i++) {
      const particle = this.particles[i];
      
      if (!particle.active) continue;
      
      particle.x += particle.vx * dt;
      particle.y += particle.vy * dt;
      particle.life -= deltaTime;
      
      if (particle.life <= 0) {
        particle.active = false;
        this.returnToPool(particle);
      } else {
        this.particles[writeIndex++] = particle;
      }
    }
    
    this.activeCount = writeIndex;
  }

  render(ctx: CanvasRenderingContext2D) {
    for (let i = 0; i < this.activeCount; i++) {
      const particle = this.particles[i];
      if (!particle.active) continue;
      
      const alpha = particle.life / particle.maxLife;
      
      ctx.save();
      ctx.globalAlpha = alpha;
      
      if (particle.type === 'star') {
        // Render star particles as small crosses
        ctx.fillStyle = particle.color;
        ctx.fillRect(particle.x - 1, particle.y, 3, 1);
        ctx.fillRect(particle.x, particle.y - 1, 1, 3);
      } else {
        // Render other particles as rectangles
        const halfSize = particle.size * 0.5;
        ctx.fillStyle = particle.color;
        ctx.fillRect(particle.x - halfSize, particle.y - halfSize, particle.size, particle.size);
      }
      
      ctx.restore();
    }
  }

  private getFromPool(): Particle {
    if (this.pool.length > 0) {
      return this.pool.pop()!;
    }
    return {
      x: 0, y: 0, vx: 0, vy: 0, life: 0, maxLife: 0,
      color: '', size: 0, type: 'dash', active: false
    };
  }
  
  private returnToPool(particle: Particle) {
    if (this.pool.length < 200) { // Cap pool size
      this.pool.push(particle);
    }
  }
  
  addDashParticles(x: number, y: number) {
    for (let i = 0; i < 8; i++) {
      const particle = this.getFromPool();
      particle.x = x + Math.random() * 48;
      particle.y = y + Math.random() * 32;
      particle.vx = -100 - Math.random() * 100;
      particle.vy = (Math.random() - 0.5) * 100;
      particle.life = 500;
      particle.maxLife = 500;
      particle.color = '#00ffff';
      particle.size = 2 + Math.random() * 2;
      particle.type = 'dash';
      particle.active = true;
      
      this.particles[this.activeCount++] = particle;
    }
  }

  addCollisionParticles(x: number, y: number) {
    for (let i = 0; i < 12; i++) {
      const particle = this.getFromPool();
      particle.x = x + 24;
      particle.y = y + 16;
      particle.vx = (Math.random() - 0.5) * 200;
      particle.vy = (Math.random() - 0.5) * 200;
      particle.life = 1000;
      particle.maxLife = 1000;
      particle.color = '#ff4444';
      particle.size = 3 + Math.random() * 3;
      particle.type = 'collision';
      particle.active = true;
      
      this.particles[this.activeCount++] = particle;
    }
  }

  addStarParticles(x: number, y: number, count: number = 1) {
    for (let i = 0; i < count; i++) {
      const particle = this.getFromPool();
      particle.x = x;
      particle.y = y + Math.random() * 400;
      particle.vx = -50 - Math.random() * 100;
      particle.vy = 0;
      particle.life = 5000;
      particle.maxLife = 5000;
      particle.color = '#ffffff';
      particle.size = 1;
      particle.type = 'star';
      particle.active = true;
      
      this.particles[this.activeCount++] = particle;
    }
  }

  clear() {
    // Return all active particles to pool
    for (let i = 0; i < this.activeCount; i++) {
      this.returnToPool(this.particles[i]);
    }
    this.activeCount = 0;
  }
}
