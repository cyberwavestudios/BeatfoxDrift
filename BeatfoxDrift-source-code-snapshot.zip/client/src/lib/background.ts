interface Star {
  x: number;
  y: number;
  speed: number;
  brightness: number;
  size: number;
  originalBrightness: number;
  pulsePhase: number;
}

interface CosmicObject {
  x: number;
  y: number;
  size: number;
  rotation: number;
  opacity: number;
  type: 'galaxy' | 'nebula' | 'blackhole' | 'stardust' | 'matrix' | 'carrier' | 'battleship' | 'fighter' | 'explosion' | 'crystal' | 'crystal_shard' | 'energy_field' | 'tower' | 'data_stream' | 'code_rain' | 'toxic_cloud' | 'acid_rain' | 'memory_fragment' | 'data_ghost' | 'energy_wisp' | 'floating_garden' | 'weapon_blackhole' | 'stellar_blackhole' | 'supermassive_blackhole' | 'primordial_blackhole' | 'data_blackhole' | 'quantum_blackhole' | 'micro_blackhole';
  phase: number;
  color?: string;
  speed?: number;
  direction?: number;
  health?: number;
}

export type SpaceSector = 
  | 'resistance'     // Resistance Nebula - red glow
  | 'toxic'          // Toxic Clouds - green haze
  | 'misty'          // Misty Void - gray atmosphere
  | 'memory'         // Memory Fields - pink/magenta
  | 'digital'        // Digital Economy - cyan matrix
  | 'war'            // War Zone - orange/red energy
  | 'crystal'        // Crystal Depths - blue crystals
  | 'memorial'       // Star Memorial - golden starlight
  | 'paradise'       // Paradise Lost - green/aqua
  | 'phase'          // Phase Shifter - purple shifting
  | 'sync'           // Sync Matrix - orange patterns
  | 'terminal'       // Terminal Station - red/pink tech
  | 'pressure'       // Pressure Zone - blue/purple
  | 'deep';          // Deep Space - dark blue/purple cosmos

export class Background {
  private stars: Star[] = [];
  private cosmicObjects: CosmicObject[] = [];
  private canvasWidth: number;
  private canvasHeight: number;
  private currentSector: SpaceSector = 'misty';
  private themeTransition: number = 0;
  private sectorProgress: number = 0;
  private lasers: { x: number; y: number; targetX: number; targetY: number; life: number; color: string }[] = [];
  
  // Secret level properties
  private isSecretLevel: boolean = false;
  private secretLevelTime: number = 0;
  private nebulaStars: { x: number; y: number; size: number; color: string; originalX: number; originalY: number }[] = [];
  
  // Eclipse Expedition starship for secret level
  private starshipImage: HTMLImageElement | null = null;
  private starshipLoaded: boolean = false;
  private starshipX: number = 0;
  private starshipY: number = 0;
  private starshipScale: number = 1;
  private starshipRotation: number = 0;
  private starshipBoostParticles: { x: number; y: number; vx: number; vy: number; life: number; maxLife: number; size: number; color: string }[] = [];
  
  // Interactive cosmic effects
  private interactiveParticles: {
    x: number;
    y: number;
    vx: number;
    vy: number;
    life: number;
    maxLife: number;
    color: string;
    size: number;
    type: 'wake' | 'proximity' | 'resonance';
  }[] = [];
  private playerX: number = 0;
  private playerY: number = 0;
  private lastPlayerX: number = 0;
  private lastPlayerY: number = 0;
  private cosmicResonance: number = 0;
  
  // Dynamic color intensity tracking
  private colorIntensity: number = 1;
  private intensityTarget: number = 1;
  private lastScoreUpdate: number = 0;

  constructor(canvasWidth: number, canvasHeight: number) {
    this.canvasWidth = canvasWidth;
    this.canvasHeight = canvasHeight;
    this.generateStars();
    this.generateNebulaStars();
    this.loadStarshipImage();
  }

  private generateStars() {
    this.stars = [];
    for (let i = 0; i < 150; i++) { // More stars for better effect
      const brightness = 0.3 + Math.random() * 0.7;
      this.stars.push({
        x: Math.random() * this.canvasWidth,
        y: Math.random() * this.canvasHeight,
        speed: 30 + Math.random() * 120, // Faster movement for side-scrolling effect
        brightness: brightness,
        originalBrightness: brightness,
        pulsePhase: Math.random() * Math.PI * 2,
        size: Math.random() < 0.15 ? 2 : 1 // More large stars
      });
    }
  }

  update(deltaTime: number, score: number = 0, playerX: number = 100, playerY: number = 300) {
    // Update player position tracking
    this.lastPlayerX = this.playerX;
    this.lastPlayerY = this.playerY;
    this.playerX = playerX;
    this.playerY = playerY;
    
    // Calculate player movement for wake effects
    const playerSpeed = Math.sqrt(
      Math.pow(this.playerX - this.lastPlayerX, 2) + 
      Math.pow(this.playerY - this.lastPlayerY, 2)
    );
    
    // Update cosmic resonance based on player movement
    this.cosmicResonance += playerSpeed * 0.01;
    this.cosmicResonance = Math.max(0, this.cosmicResonance - deltaTime * 0.001);
    
    // Update dynamic color intensity based on score progression and activity
    const scoreIncrease = score - this.lastScoreUpdate;
    if (scoreIncrease > 0) {
      this.intensityTarget = Math.min(2.0, 1 + (score * 0.002) + (playerSpeed * 0.05));
      this.lastScoreUpdate = score;
    } else {
      this.intensityTarget = Math.max(0.7, this.intensityTarget - deltaTime * 0.0001);
    }
    
    // Smooth transition of color intensity
    const intensityDiff = this.intensityTarget - this.colorIntensity;
    this.colorIntensity += intensityDiff * Math.min(1, deltaTime * 0.002);

    // Update theme transition
    this.themeTransition = Math.max(0, this.themeTransition - deltaTime * 0.002);

    // Enhanced movement variations that respond to cosmic resonance
    const timeVariation = Math.sin(Date.now() * 0.001) * 0.2 + 0.9;
    const resonanceVariation = 1 + this.cosmicResonance * 0.3;

    // Move stars for side-scrolling effect with interactive brightness
    for (const star of this.stars) {
      star.x -= star.speed * (deltaTime / 1000) * timeVariation * resonanceVariation;
      
      // Update pulse phase for smooth brightness animation
      star.pulsePhase += deltaTime * 0.001;
      
      // Interactive brightness based on player proximity and cosmic resonance
      const distanceToPlayer = Math.sqrt(
        Math.pow(star.x - this.playerX, 2) + Math.pow(star.y - this.playerY, 2)
      );
      const proximityEffect = Math.max(0, 1 - distanceToPlayer / 200);
      const resonanceEffect = Math.sin(star.pulsePhase + this.cosmicResonance) * 0.3;
      
      star.brightness = star.originalBrightness + proximityEffect * 0.5 + resonanceEffect * 0.2;
      star.brightness = Math.max(0.1, Math.min(1.2, star.brightness));
      
      // Wrap around when star goes off-screen
      if (star.x < -10) {
        star.x = this.canvasWidth + Math.random() * 20;
        star.y = Math.random() * this.canvasHeight;
        star.speed = 30 + Math.random() * 120;
        const brightness = 0.3 + Math.random() * 0.7;
        star.originalBrightness = brightness;
        star.brightness = brightness;
        star.pulsePhase = Math.random() * Math.PI * 2;
      }
    }

    // Update cosmic objects with MUSIC-SYNCED movement for epic effects
    for (let i = this.cosmicObjects.length - 1; i >= 0; i--) {
      const obj = this.cosmicObjects[i];
      
      // Custom movement speeds based on object type with MUSIC SYNC
      let moveSpeed = 20 + obj.size * 0.1;
      if (obj.speed) {
        moveSpeed = obj.speed;
      }
      
      // Interactive movement and rotation with cosmic resonance
      obj.x -= moveSpeed * (deltaTime / 1000) * timeVariation * resonanceVariation;
      obj.rotation += deltaTime * 0.001 * (1 + this.cosmicResonance * 0.5); // Resonance-affected rotation
      obj.phase += deltaTime * 0.003 * (1 + this.cosmicResonance * 0.2); // Resonance-affected phase changes
      
      // Player proximity effects on cosmic objects
      const objCenterX = obj.x + obj.size / 2;
      const objCenterY = obj.y + obj.size / 2;
      const distanceToPlayer = Math.sqrt(
        Math.pow(objCenterX - this.playerX, 2) + Math.pow(objCenterY - this.playerY, 2)
      );
      
      // Create proximity particles for nearby objects
      if (distanceToPlayer < obj.size * 2 && Math.random() < 0.02) {
        this.createProximityParticle(objCenterX, objCenterY);
      }

      // War Zone: Create laser battles between ships
      if (this.currentSector === 'war' && (obj.type === 'carrier' || obj.type === 'battleship') && Math.random() < 0.02) {
        // Find target ships to shoot at
        const targets = this.cosmicObjects.filter(target => 
          target !== obj && 
          (target.type === 'carrier' || target.type === 'battleship' || target.type === 'fighter') &&
          Math.abs(target.y - obj.y) < 150
        );
        
        if (targets.length > 0) {
          const target = targets[Math.floor(Math.random() * targets.length)];
          this.lasers.push({
            x: obj.x,
            y: obj.y,
            targetX: target.x,
            targetY: target.y,
            life: 1000, // 1 second laser duration
            color: '#ff3333'
          });
        }
      }

      // Reduce health for explosion effects
      if (obj.health && obj.health > 0) {
        obj.health -= deltaTime * 0.05;
        if (obj.health <= 0) {
          this.cosmicObjects.splice(i, 1);
          continue;
        }
      }
      
      // Remove objects that are off-screen
      if (obj.x + obj.size < -50) {
        this.cosmicObjects.splice(i, 1);
      }
    }

    // Update lasers
    for (let i = this.lasers.length - 1; i >= 0; i--) {
      const laser = this.lasers[i];
      laser.life -= deltaTime;
      
      if (laser.life <= 0) {
        this.lasers.splice(i, 1);
      }
    }

    // Handle secret level updates
    if (this.isSecretLevel) {
      this.secretLevelTime += deltaTime;
      this.updateNebulaCollapse();
      
      // Skip normal cosmic object spawning in secret level
    } else {
      // Generate player wake particles
      this.createWakeParticles(playerSpeed, deltaTime);
      
      // Update interactive particles
      this.updateInteractiveParticles(deltaTime);
      
      // Spawn immersive cosmic objects for sector-themed backgrounds
      if (Math.random() < 0.005) { // Moderate spawn rate
        this.spawnCosmicObject();
      }
      
      // Maintain good background density
      if (this.cosmicObjects.length < 5) {
        this.spawnCosmicObject();
      }
    }
  }

  private generateNebulaStars() {
    this.nebulaStars = [];
    // Create two large nebula "stars" that will collapse into each other
    const centerX = this.canvasWidth / 2;
    const centerY = this.canvasHeight / 2;
    
    // First nebula (left side, red-orange)
    this.nebulaStars.push({
      x: centerX - 200,
      y: centerY - 80,
      originalX: centerX - 200,
      originalY: centerY - 80,
      size: 120,
      color: '#ff4400'
    });
    
    // Second nebula (right side, blue-white)
    this.nebulaStars.push({
      x: centerX + 200,
      y: centerY + 80,
      originalX: centerX + 200,
      originalY: centerY + 80,
      size: 100,
      color: '#4488ff'
    });
  }
  
  private updateNebulaCollapse() {
    const centerX = this.canvasWidth / 2;
    const centerY = this.canvasHeight / 2;
    const collapseSpeed = Math.min(this.secretLevelTime / 25000, 1); // Over 25 seconds
    
    for (const nebula of this.nebulaStars) {
      if (collapseSpeed < 1) {
        // Move towards center
        const dx = centerX - nebula.originalX;
        const dy = centerY - nebula.originalY;
        nebula.x = nebula.originalX + dx * collapseSpeed;
        nebula.y = nebula.originalY + dy * collapseSpeed;
      }
    }
  }
  
  setSecretLevel(enabled: boolean) {
    this.isSecretLevel = enabled;
    if (enabled) {
      this.secretLevelTime = 0;
      this.generateNebulaStars();
      // Clear cosmic objects for clean secret level view
      this.cosmicObjects = [];
      
      // Reset starship position when entering secret level (off-screen)
      this.starshipX = this.canvasWidth + 150; // Start off-screen to the right
      this.starshipY = this.canvasHeight * 0.7;
      this.starshipScale = 0.8;
      this.starshipRotation = 0;
      this.starshipBoostParticles = [];
    }
  }
  
  // Interactive particle creation methods
  private createWakeParticles(playerSpeed: number, deltaTime: number) {
    if (playerSpeed > 2 && Math.random() < 0.3) {
      const wakeColor = this.getSectorColor();
      const angle = Math.atan2(this.playerY - this.lastPlayerY, this.playerX - this.lastPlayerX) + Math.PI;
      
      for (let i = 0; i < 3; i++) {
        this.interactiveParticles.push({
          x: this.playerX + Math.random() * 20 - 10,
          y: this.playerY + Math.random() * 20 - 10,
          vx: Math.cos(angle + (Math.random() - 0.5) * 0.5) * (50 + Math.random() * 30),
          vy: Math.sin(angle + (Math.random() - 0.5) * 0.5) * (50 + Math.random() * 30),
          life: 1000 + Math.random() * 1000,
          maxLife: 2000,
          color: wakeColor,
          size: 2 + Math.random() * 3,
          type: 'wake'
        });
      }
    }
  }
  
  private createProximityParticle(x: number, y: number) {
    const proximityColor = this.getSectorColor();
    const angle = Math.random() * Math.PI * 2;
    
    this.interactiveParticles.push({
      x: x,
      y: y,
      vx: Math.cos(angle) * (20 + Math.random() * 40),
      vy: Math.sin(angle) * (20 + Math.random() * 40),
      life: 800 + Math.random() * 400,
      maxLife: 1200,
      color: proximityColor,
      size: 1 + Math.random() * 2,
      type: 'proximity'
    });
  }
  
  private createResonanceParticles() {
    if (this.cosmicResonance > 5 && Math.random() < 0.1) {
      const resonanceColor = this.getSectorColor();
      
      for (let i = 0; i < 5; i++) {
        const angle = (Math.PI * 2 / 5) * i + this.cosmicResonance * 0.1;
        const radius = 30 + this.cosmicResonance * 2;
        
        this.interactiveParticles.push({
          x: this.playerX + Math.cos(angle) * radius,
          y: this.playerY + Math.sin(angle) * radius,
          vx: Math.cos(angle) * 30,
          vy: Math.sin(angle) * 30,
          life: 1500,
          maxLife: 1500,
          color: resonanceColor,
          size: 2,
          type: 'resonance'
        });
      }
    }
  }
  
  private updateInteractiveParticles(deltaTime: number) {
    for (let i = this.interactiveParticles.length - 1; i >= 0; i--) {
      const particle = this.interactiveParticles[i];
      
      // Update position
      particle.x += particle.vx * (deltaTime / 1000);
      particle.y += particle.vy * (deltaTime / 1000);
      
      // Fade based on life
      particle.life -= 16.67; // Use fixed deltaTime for consistency
      
      // Apply drag
      particle.vx *= 0.98;
      particle.vy *= 0.98;
      
      // Remove dead particles
      if (particle.life <= 0) {
        this.interactiveParticles.splice(i, 1);
      }
    }
    
    // Create resonance particles
    this.createResonanceParticles();
  }
  
  private getSectorColor(): string {
    switch (this.currentSector) {
      case 'resistance': return '#ff4444';
      case 'toxic': return '#44ff44';
      case 'memory': return '#ff44ff';
      case 'digital': return '#44ffff';
      case 'war': return '#ff6600';
      case 'crystal': return '#4488ff';
      case 'memorial': return '#ffff44';
      case 'paradise': return '#88ffaa';
      case 'phase': return '#aa44ff';
      case 'sync': return '#ffaa44';
      case 'terminal': return '#ff4488';
      case 'pressure': return '#4466aa';
      case 'deep': return '#2244ff';
      default: return '#ffffff';
    }
  }

  // Method to be called when music track changes
  setSector(sectorName: string, sectorColor: string) {
    // Map sector names to background types
    let newSector: SpaceSector = 'misty'; // Default
    
    if (sectorName.includes('Resistance')) newSector = 'resistance';
    else if (sectorName.includes('Toxic')) newSector = 'toxic';
    else if (sectorName.includes('Misty')) newSector = 'misty';
    else if (sectorName.includes('Memory')) newSector = 'memory';
    else if (sectorName.includes('Digital')) newSector = 'digital';
    else if (sectorName.includes('War')) newSector = 'war';
    else if (sectorName.includes('Crystal')) newSector = 'crystal';
    else if (sectorName.includes('Memorial')) newSector = 'memorial';
    else if (sectorName.includes('Paradise')) newSector = 'paradise';
    else if (sectorName.includes('Phase')) newSector = 'phase';
    else if (sectorName.includes('Sync')) newSector = 'sync';
    else if (sectorName.includes('Terminal')) newSector = 'terminal';
    else if (sectorName.includes('Pressure')) newSector = 'pressure';
    else if (sectorName.includes('Deep')) newSector = 'deep';
    
    if (newSector !== this.currentSector) {
      console.log(`Music-driven sector change: Entering ${sectorName}`);
      this.currentSector = newSector;
      this.themeTransition = 0.8; // Flash effect when entering new sector
      this.cosmicObjects = []; // Clear old objects
    }
  }

  private spawnCosmicObject() {
    const obj: CosmicObject = {
      x: this.canvasWidth + Math.random() * 200,
      y: Math.random() * this.canvasHeight,
      size: 80 + Math.random() * 180, // LARGER objects for epic scale
      rotation: 0,
      opacity: 0.2 + Math.random() * 0.3, // Reduced opacity to differentiate from gameplay objects
      type: 'nebula', // Default type
      phase: Math.random() * Math.PI * 2
    };
    
    // Assign cosmic object types based on music-driven sectors with awesome effects
    switch (this.currentSector) {
      case 'war':
        // WAR ZONE: Weapon-created black holes consuming fleets
        const warRand = Math.random();
        if (warRand < 0.4) {
          obj.type = 'weapon_blackhole';
          obj.size = 80 + Math.random() * 60; // Weapon-generated black holes
          obj.speed = 25 + Math.random() * 35;
          obj.color = '#ff2200';
        } else if (warRand < 0.6) {
          obj.type = 'carrier';
          obj.size = 60 + Math.random() * 40; // Military carriers being consumed
          obj.speed = 40 + Math.random() * 60;
          obj.color = '#ff6600';
        } else if (warRand < 0.8) {
          obj.type = 'battleship';
          obj.size = 40 + Math.random() * 30; // Battle cruisers fleeing
          obj.speed = 65 + Math.random() * 85;
          obj.color = '#ff4400';
        } else {
          obj.type = 'stardust';
          obj.size = 30 + Math.random() * 40; // Debris from destroyed ships
          obj.speed = 70 + Math.random() * 90;
          obj.color = '#cc4400';
        }
        break;
      case 'crystal':
        // CRYSTAL DEPTHS: Crystal-formed black holes with geometric accretion disks
        const crystalRand = Math.random();
        if (crystalRand < 0.45) {
          obj.type = 'stellar_blackhole';
          obj.size = 90 + Math.random() * 70; // Crystal-formed black holes
          obj.color = '#0044aa';
          obj.speed = 20 + Math.random() * 30;
        } else if (crystalRand < 0.7) {
          obj.type = 'crystal';
          obj.size = 45 + Math.random() * 55; // Crystals orbiting black holes
          obj.color = '#4488ff';
          obj.speed = 35 + Math.random() * 55;
        } else {
          obj.type = 'crystal_shard';
          obj.size = 20 + Math.random() * 30; // Crystal debris from tidal forces
          obj.speed = 60 + Math.random() * 80;
          obj.color = '#66aaff';
        }
        break;
      case 'digital':
      case 'sync':
        // DIGITAL ECONOMY/SYNC MATRIX: Data streams, towers, and code rain
        const digitalRand = Math.random();
        if (digitalRand < 0.4) {
          obj.type = 'data_stream';
          obj.size = 20 + Math.random() * 60;
          obj.color = '#00ffff';
          obj.speed = 100 + Math.random() * 150;
        } else if (digitalRand < 0.7) {
          obj.type = 'tower';
          obj.size = 60 + Math.random() * 120;
          obj.color = '#00ff88';
          obj.speed = 25 + Math.random() * 50;
        } else {
          obj.type = 'code_rain';
          obj.size = 8 + Math.random() * 12;
          obj.speed = 200 + Math.random() * 250;
          obj.color = '#00ff00';
        }
        break;
      case 'resistance':
        // RESISTANCE NEBULA: Micro black holes from failed resistance weapons
        const resistanceRand = Math.random();
        if (resistanceRand < 0.5) {
          obj.type = 'micro_blackhole';
          obj.size = 40 + Math.random() * 50; // Small weapons-grade black holes
          obj.color = '#dd2222';
          obj.speed = 40 + Math.random() * 60;
        } else {
          obj.type = 'galaxy';
          obj.size = 60 + Math.random() * 80; // Distant galaxies behind the war
          obj.color = '#ff4444';
          obj.speed = 25 + Math.random() * 35;
        }
        break;
      case 'terminal':
        // TERMINAL STATION: AI-created black holes as computational singularities
        const terminalRand = Math.random();
        if (terminalRand < 0.6) {
          obj.type = 'data_blackhole';
          obj.size = 80 + Math.random() * 70; // Computational singularities
          obj.color = '#ff6688';
          obj.speed = 15 + Math.random() * 25;
        } else {
          obj.type = 'galaxy';
          obj.size = 70 + Math.random() * 90; // Background galaxies
          obj.color = '#ff8888';
          obj.speed = 30 + Math.random() * 40;
        }
        break;
      case 'toxic':
        // TOXIC CLOUDS: Acid rain and toxic gas
        const toxicRand = Math.random();
        if (toxicRand < 0.7) {
          obj.type = 'toxic_cloud';
          obj.size = 80 + Math.random() * 120;
          obj.color = '#44ff44';
          obj.speed = 40 + Math.random() * 60;
        } else {
          obj.type = 'acid_rain';
          obj.size = 5 + Math.random() * 8;
          obj.speed = 150 + Math.random() * 200;
          obj.color = '#66ff22';
        }
        break;
      case 'memory':
        // MEMORY FIELDS: Information black holes consuming lost data
        const memoryRand = Math.random();
        if (memoryRand < 0.4) {
          obj.type = 'data_blackhole';
          obj.size = 70 + Math.random() * 60; // Black holes that consume information
          obj.color = '#bb44bb';
          obj.speed = 20 + Math.random() * 30;
        } else if (memoryRand < 0.7) {
          obj.type = 'memory_fragment';
          obj.size = 35 + Math.random() * 45; // Data being pulled toward black holes
          obj.color = '#ff88ff';
          obj.speed = 50 + Math.random() * 70;
        } else {
          obj.type = 'data_ghost';
          obj.size = 40 + Math.random() * 50; // Echoes of consumed data
          obj.color = '#aa66aa';
          obj.speed = 35 + Math.random() * 55;
        }
        break;
      case 'paradise':
        // PARADISE LOST: Floating gardens and energy wisps
        const paradiseRand = Math.random();
        if (paradiseRand < 0.6) {
          obj.type = 'energy_wisp';
          obj.size = 25 + Math.random() * 45;
          obj.color = '#88ffaa';
          obj.speed = 60 + Math.random() * 100;
        } else {
          obj.type = 'floating_garden';
          obj.size = 80 + Math.random() * 120;
          obj.color = '#aaffaa';
          obj.speed = 35 + Math.random() * 55;
        }
        break;
      case 'pressure':
        // PRESSURE ZONE: Collapsed stars creating gravitational wells
        const pressureRand = Math.random();
        if (pressureRand < 0.6) {
          obj.type = 'stellar_blackhole';
          obj.size = 60 + Math.random() * 80; // Recently collapsed stars
          obj.color = '#4466aa';
          obj.speed = 30 + Math.random() * 40;
        } else {
          obj.type = 'stardust';
          obj.size = 35 + Math.random() * 45; // Matter being compressed
          obj.color = '#6688bb';
          obj.speed = 55 + Math.random() * 75;
        }
        break;
      case 'memorial':
      case 'phase':
        // PHASE SHIFTER: Quantum black holes shifting between dimensions
        const phaseRand = Math.random();
        if (phaseRand < 0.5) {
          obj.type = 'quantum_blackhole';
          obj.size = 60 + Math.random() * 70; // Quantum black holes phasing in/out
          obj.color = '#aa66ff';
          obj.speed = 25 + Math.random() * 35;
        } else if (phaseRand < 0.75) {
          obj.type = 'nebula';
          obj.size = 50 + Math.random() * 60; // Dimensional rifts
          obj.color = '#8866ff';
          obj.speed = 35 + Math.random() * 45;
        } else {
          obj.type = 'stardust';
          obj.size = 30 + Math.random() * 40; // Phase particles
          obj.color = '#bb88ff';
          obj.speed = 60 + Math.random() * 80;
        }
        break;
      case 'deep':
        // DEEP SPACE: Ancient supermassive black holes shaping galaxies
        const deepRand = Math.random();
        if (deepRand < 0.5) {
          obj.type = 'supermassive_blackhole';
          obj.size = 100 + Math.random() * 80; // Ancient supermassive black holes
          obj.color = '#2244ff';
          obj.speed = 15 + Math.random() * 25;
        } else if (deepRand < 0.75) {
          obj.type = 'galaxy';
          obj.size = 70 + Math.random() * 60; // Galaxies being shaped by black holes
          obj.color = '#4466ff';
          obj.speed = 20 + Math.random() * 30;
        } else {
          obj.type = 'stardust';
          obj.size = 40 + Math.random() * 50; // Matter streams toward black holes
          obj.color = '#6688ff';
          obj.speed = 50 + Math.random() * 70;
        }
        break;
      default:
        obj.size = 60 + Math.random() * 100;
        obj.type = 'nebula';
        break;
    }
    
    this.cosmicObjects.push(obj);
  }

  render(ctx: CanvasRenderingContext2D) {
    if (this.isSecretLevel) {
      this.renderSecretLevel(ctx);
      return;
    }
    
    // Background gradient based on sector with dynamic intensity
    let colorStart, colorEnd;
    const intensity = this.colorIntensity;
    
    switch (this.currentSector) {
      case 'resistance':
        colorStart = this.adjustColorIntensity('#440011', intensity);
        colorEnd = this.adjustColorIntensity('#661122', intensity);
        break;
      case 'toxic':
        colorStart = this.adjustColorIntensity('#114400', intensity);
        colorEnd = this.adjustColorIntensity('#226600', intensity);
        break;
      case 'misty':
        colorStart = this.adjustColorIntensity('#222222', intensity);
        colorEnd = this.adjustColorIntensity('#444444', intensity);
        break;
      case 'memory':
        colorStart = this.adjustColorIntensity('#440044', intensity);
        colorEnd = this.adjustColorIntensity('#880088', intensity);
        break;
      case 'digital':
        colorStart = this.adjustColorIntensity('#004444', intensity);
        colorEnd = this.adjustColorIntensity('#006666', intensity);
        break;
      case 'war':
        colorStart = this.adjustColorIntensity('#662200', intensity);
        colorEnd = this.adjustColorIntensity('#aa4400', intensity);
        break;
      case 'crystal':
        colorStart = this.adjustColorIntensity('#000044', intensity);
        colorEnd = this.adjustColorIntensity('#002288', intensity);
        break;
      case 'memorial':
        colorStart = this.adjustColorIntensity('#444400', intensity);
        colorEnd = this.adjustColorIntensity('#666600', intensity);
        break;
      case 'paradise':
        colorStart = this.adjustColorIntensity('#004422', intensity);
        colorEnd = this.adjustColorIntensity('#006644', intensity);
        break;
      case 'phase':
        colorStart = this.adjustColorIntensity('#220044', intensity);
        colorEnd = this.adjustColorIntensity('#440088', intensity);
        break;
      case 'sync':
        colorStart = this.adjustColorIntensity('#442200', intensity);
        colorEnd = this.adjustColorIntensity('#664400', intensity);
        break;
      case 'terminal':
        colorStart = this.adjustColorIntensity('#440022', intensity);
        colorEnd = this.adjustColorIntensity('#660044', intensity);
        break;
      case 'pressure':
        colorStart = this.adjustColorIntensity('#002244', intensity);
        colorEnd = this.adjustColorIntensity('#004466', intensity);
        break;
      case 'deep':
        colorStart = this.adjustColorIntensity('#000033', intensity);
        colorEnd = this.adjustColorIntensity('#001155', intensity);
        break;
      default:
        colorStart = this.adjustColorIntensity('#001122', intensity);
        colorEnd = this.adjustColorIntensity('#003344', intensity);
        break;
    }

    const gradient = ctx.createLinearGradient(0, 0, 0, this.canvasHeight);
    gradient.addColorStop(0, colorStart);
    gradient.addColorStop(1, colorEnd);
    
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, this.canvasWidth, this.canvasHeight);

    // Render SPECTACULAR cosmic objects with smooth transitions
    for (const obj of this.cosmicObjects) {
      // Apply cosmic environment transitions for seamless sector changes
      if ((obj as any).transitionAlpha !== undefined && (obj as any).transitionAlpha < 1) {
        ctx.save();
        ctx.globalAlpha = (obj as any).transitionAlpha;
        this.renderCosmicObject(ctx, obj);
        ctx.restore();
        
        // Update transition smoothness
        (obj as any).transitionAlpha = Math.min(1, (obj as any).transitionAlpha + 16.67 * 0.001);
      } else {
        this.renderCosmicObject(ctx, obj);
      }
    }

    // Render interactive particles first (behind stars)
    this.renderInteractiveParticles(ctx);
    
    // Render stars with enhanced brightness and proximity glow
    for (const star of this.stars) {
      const alpha = star.brightness * (1 - this.themeTransition * 0.5);
      
      // Add glow effect for bright stars near player
      const distanceToPlayer = Math.sqrt(
        Math.pow(star.x - this.playerX, 2) + Math.pow(star.y - this.playerY, 2)
      );
      const proximityGlow = Math.max(0, 1 - distanceToPlayer / 150);
      
      if (proximityGlow > 0.1 && star.brightness > 0.8) {
        // Render glow
        const glowSize = 3 + proximityGlow * 2;
        const gradient = ctx.createRadialGradient(
          star.x, star.y, 0,
          star.x, star.y, glowSize
        );
        const sectorColor = this.getSectorColor();
        gradient.addColorStop(0, sectorColor + '80');
        gradient.addColorStop(1, 'transparent');
        
        ctx.fillStyle = gradient;
        ctx.fillRect(
          star.x - glowSize, star.y - glowSize,
          glowSize * 2, glowSize * 2
        );
      }
      
      // Render star
      ctx.fillStyle = `rgba(255, 255, 255, ${alpha})`;
      
      if (star.size > 1) {
        // Large star with cross pattern
        const starSize = 1 + proximityGlow * 0.5;
        ctx.fillRect(star.x - starSize, star.y, starSize * 2 + 1, 1);
        ctx.fillRect(star.x, star.y - starSize, 1, starSize * 2 + 1);
      } else {
        // Small star
        ctx.fillRect(star.x, star.y, 1, 1);
      }
    }

    // Render war zone laser battles
    this.renderLasers(ctx);

    // Theme transition flash effect with cosmic resonance
    if (this.themeTransition > 0) {
      const flashIntensity = this.themeTransition * (1 + this.cosmicResonance * 0.1);
      const sectorColor = this.getSectorColor();
      
      // Create a sector-colored flash instead of white
      ctx.fillStyle = sectorColor + Math.floor(flashIntensity * 255).toString(16).padStart(2, '0');
      ctx.fillRect(0, 0, this.canvasWidth, this.canvasHeight);
    }
    
    // Render cosmic resonance field around player
    if (this.cosmicResonance > 3) {
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      ctx.globalAlpha = Math.min(0.3, this.cosmicResonance * 0.02);
      
      const fieldRadius = 50 + this.cosmicResonance * 5;
      const gradient = ctx.createRadialGradient(
        this.playerX, this.playerY, 0,
        this.playerX, this.playerY, fieldRadius
      );
      
      const sectorColor = this.getSectorColor();
      gradient.addColorStop(0, sectorColor);
      gradient.addColorStop(0.7, sectorColor + '40');
      gradient.addColorStop(1, 'transparent');
      
      ctx.fillStyle = gradient;
      ctx.fillRect(
        this.playerX - fieldRadius, this.playerY - fieldRadius,
        fieldRadius * 2, fieldRadius * 2
      );
      
      ctx.restore();
    }
  }
  
  private renderInteractiveParticles(ctx: CanvasRenderingContext2D) {
    ctx.save();
    
    for (const particle of this.interactiveParticles) {
      const lifeRatio = particle.life / particle.maxLife;
      const alpha = Math.min(1, lifeRatio * 2); // Fade in quickly, fade out slowly
      
      ctx.globalAlpha = alpha;
      ctx.fillStyle = particle.color;
      
      // Different rendering based on particle type
      switch (particle.type) {
        case 'wake':
          // Elongated wake particles
          ctx.fillRect(particle.x - particle.size/2, particle.y - 0.5, particle.size, 1);
          break;
        case 'proximity':
          // Circular proximity particles
          ctx.beginPath();
          ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
          ctx.fill();
          break;
        case 'resonance':
          // Pulsing resonance particles
          const pulseSize = particle.size * (1 + Math.sin(Date.now() * 0.01) * 0.3);
          ctx.beginPath();
          ctx.arc(particle.x, particle.y, pulseSize, 0, Math.PI * 2);
          ctx.fill();
          break;
      }
    }
    
    ctx.restore();
  }
  
  // Helper method to adjust color intensity dynamically
  private adjustColorIntensity(hexColor: string, intensity: number): string {
    // Parse hex color
    const r = parseInt(hexColor.slice(1, 3), 16);
    const g = parseInt(hexColor.slice(3, 5), 16);
    const b = parseInt(hexColor.slice(5, 7), 16);
    
    // Apply intensity multiplier with intelligent scaling
    const newR = Math.min(255, Math.floor(r * intensity));
    const newG = Math.min(255, Math.floor(g * intensity));
    const newB = Math.min(255, Math.floor(b * intensity));
    
    // Convert back to hex
    return `#${newR.toString(16).padStart(2, '0')}${newG.toString(16).padStart(2, '0')}${newB.toString(16).padStart(2, '0')}`;
  }
  
  // Enhanced cosmic object interaction with proximity distortion
  private applyProximityDistortion(obj: CosmicObject): number {
    const distanceToPlayer = Math.sqrt(
      Math.pow(obj.x - this.playerX, 2) + Math.pow(obj.y - this.playerY, 2)
    );
    
    // Create distortion effect based on proximity
    const maxProximityEffect = obj.size * 3;
    const proximityRatio = Math.max(0, 1 - distanceToPlayer / maxProximityEffect);
    
    // Return intensity multiplier for proximity effects
    return 1 + proximityRatio * this.cosmicResonance * 0.1;
  }

  private renderCosmicObject(ctx: CanvasRenderingContext2D, obj: CosmicObject) {
    ctx.save();
    
    // Apply proximity-based opacity and size modifications
    const proximityIntensity = this.applyProximityDistortion(obj);
    ctx.globalAlpha = obj.opacity * Math.min(1.2, proximityIntensity);
    
    // Scale size based on proximity and cosmic resonance
    const sizeMultiplier = proximityIntensity * (1 + this.cosmicResonance * 0.02);
    
    const centerX = obj.x + obj.size / 2;
    const centerY = obj.y + obj.size / 2;
    
    switch (obj.type) {
      case 'galaxy':
        this.renderGalaxy(ctx, centerX, centerY, obj.size, obj.rotation, obj.phase);
        break;
      case 'nebula':
        this.renderNebula(ctx, centerX, centerY, obj.size, obj.phase);
        break;
      case 'blackhole':
        this.renderBlackhole(ctx, centerX, centerY, obj.size, obj.phase);
        break;
      case 'weapon_blackhole':
        this.renderWeaponBlackhole(ctx, centerX, centerY, obj.size, obj.phase);
        break;
      case 'stellar_blackhole':
        this.renderStellarBlackhole(ctx, centerX, centerY, obj.size, obj.phase);
        break;
      case 'supermassive_blackhole':
        this.renderSupermassiveBlackhole(ctx, centerX, centerY, obj.size, obj.phase);
        break;
      case 'primordial_blackhole':
        this.renderPrimordialBlackhole(ctx, centerX, centerY, obj.size, obj.phase);
        break;
      case 'data_blackhole':
        this.renderDataBlackhole(ctx, centerX, centerY, obj.size, obj.phase);
        break;
      case 'quantum_blackhole':
        this.renderQuantumBlackhole(ctx, centerX, centerY, obj.size, obj.phase);
        break;
      case 'micro_blackhole':
        this.renderMicroBlackhole(ctx, centerX, centerY, obj.size, obj.phase);
        break;
      case 'stardust':
        this.renderStardust(ctx, centerX, centerY, obj.size, obj.phase);
        break;
      case 'matrix':
        this.renderMatrix(ctx, centerX, centerY, obj.size, obj.phase);
        break;
      case 'carrier':
        this.renderCarrier(ctx, centerX, centerY, obj.size, obj.phase, obj.color || '#ff6600');
        break;
      case 'battleship':
        this.renderBattleship(ctx, centerX, centerY, obj.size, obj.phase, obj.color || '#ff4400');
        break;
      case 'fighter':
        this.renderFighter(ctx, centerX, centerY, obj.size, obj.phase, obj.color || '#ffaa00');
        break;
      case 'explosion':
        this.renderExplosion(ctx, centerX, centerY, obj.size, obj.phase, obj.color || '#ff2200');
        break;
      case 'crystal':
        this.renderCrystal(ctx, centerX, centerY, obj.size, obj.phase, obj.color || '#0066ff');
        break;
      case 'crystal_shard':
        this.renderCrystalShard(ctx, centerX, centerY, obj.size, obj.phase, obj.color || '#4488ff');
        break;
      case 'energy_field':
        this.renderEnergyField(ctx, centerX, centerY, obj.size, obj.phase, obj.color || '#88aaff');
        break;
      case 'data_stream':
        this.renderDataStream(ctx, centerX, centerY, obj.size, obj.phase, obj.color || '#00ffff');
        break;
      case 'tower':
        this.renderTower(ctx, centerX, centerY, obj.size, obj.phase, obj.color || '#00ff88');
        break;
      case 'code_rain':
        this.renderCodeRain(ctx, centerX, centerY, obj.size, obj.phase, obj.color || '#00ff00');
        break;
      case 'toxic_cloud':
        this.renderToxicCloud(ctx, centerX, centerY, obj.size, obj.phase, obj.color || '#44ff44');
        break;
      case 'acid_rain':
        this.renderAcidRain(ctx, centerX, centerY, obj.size, obj.phase, obj.color || '#66ff22');
        break;
      case 'memory_fragment':
        this.renderMemoryFragment(ctx, centerX, centerY, obj.size, obj.phase, obj.color || '#ff88ff');
        break;
      case 'data_ghost':
        this.renderDataGhost(ctx, centerX, centerY, obj.size, obj.phase, obj.color || '#aa66aa');
        break;
      case 'energy_wisp':
        this.renderEnergyWisp(ctx, centerX, centerY, obj.size, obj.phase, obj.color || '#88ffaa');
        break;
      case 'floating_garden':
        this.renderFloatingGarden(ctx, centerX, centerY, obj.size, obj.phase, obj.color || '#aaffaa');
        break;
    }
    
    ctx.restore();
  }

  private renderGalaxy(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, rotation: number, phase: number) {
    // Render galaxy as elongated spiral shape instead of circular
    const spiralArms = 3;
    const innerRadius = size * 0.15;
    const outerRadius = size * 0.6;
    
    for (let arm = 0; arm < spiralArms; arm++) {
      const armAngle = (arm / spiralArms) * Math.PI * 2 + rotation;
      
      for (let i = 0; i < 15; i++) {
        const t = i / 14;
        const radius = innerRadius + t * outerRadius;
        const angle = armAngle + t * Math.PI * 3;
        
        // Elongated galaxy shape
        const ellipseX = Math.cos(angle) * radius * (0.7 + t * 0.3);
        const ellipseY = Math.sin(angle) * radius * (0.4 + t * 0.2);
        
        const starX = x + ellipseX;
        const starY = y + ellipseY;
        const brightness = (1 - t) * 0.6 + Math.sin(phase + i) * 0.15;
        
        ctx.fillStyle = `rgba(150, 150, 255, ${brightness})`;
        ctx.fillRect(starX - 1, starY - 1, 2, 1); // Rectangular stars, not circular
      }
    }
  }

  private renderNebula(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, phase: number) {
    // Render nebula as flowing cloud formations instead of circular
    const cloudCount = 6;
    
    for (let i = 0; i < cloudCount; i++) {
      const offsetX = (Math.sin(phase + i) * size * 0.4);
      const offsetY = (Math.cos(phase + i * 0.7) * size * 0.3);
      
      const cloudX = x + offsetX;
      const cloudY = y + offsetY;
      const cloudWidth = size * 0.3 + Math.sin(phase + i * 0.5) * size * 0.1;
      const cloudHeight = size * 0.2 + Math.cos(phase + i * 0.3) * size * 0.1;
      
      const opacity = 0.25 + Math.sin(phase + i) * 0.15;
      ctx.fillStyle = `rgba(255, 100, 200, ${opacity})`;
      
      // Draw irregular cloud shapes - no circles
      ctx.fillRect(cloudX - cloudWidth/2, cloudY - cloudHeight/2, cloudWidth, cloudHeight);
      ctx.fillRect(cloudX - cloudWidth/3, cloudY - cloudHeight/3, cloudWidth * 0.7, cloudHeight * 0.6);
    }
  }

  private renderBlackhole(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, phase: number) {
    // Render as distorted space-time effect instead of circular
    const waveCount = 6;
    
    for (let i = 0; i < waveCount; i++) {
      const waveAngle = (i / waveCount) * Math.PI * 2 + phase;
      const waveLength = size * (0.4 + i * 0.1);
      const brightness = 0.6 - i * 0.1 + Math.sin(phase + i) * 0.2;
      
      const waveX = x + Math.cos(waveAngle) * waveLength * 0.3;
      const waveY = y + Math.sin(waveAngle) * waveLength * 0.6;
      
      ctx.fillStyle = `rgba(255, 150, 50, ${Math.max(0, brightness)})`;
      // Draw as irregular distortion effects
      ctx.fillRect(waveX - 2, waveY - 1, 4, 2);
      ctx.fillRect(waveX - 1, waveY - 2, 2, 4);
    }
    
    // Dark center as rectangular void
    ctx.fillStyle = '#000000';
    ctx.fillRect(x - size * 0.1, y - size * 0.1, size * 0.2, size * 0.2);
  }

  // WAR ZONE: Weapon-created black holes with red energy discharges
  private renderWeaponBlackhole(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, phase: number) {
    // Accretion disk with violent energy
    const diskRadius = size * 0.6;
    for (let ring = 0; ring < 5; ring++) {
      const radius = diskRadius * (0.4 + ring * 0.15);
      const brightness = 0.8 - ring * 0.15 + Math.sin(phase * 2 + ring) * 0.2;
      
      ctx.fillStyle = `rgba(255, 80, 0, ${Math.max(0, brightness)})`;
      ctx.beginPath();
      ctx.arc(x, y, radius, 0, Math.PI * 2);
      ctx.fill();
    }
    
    // Event horizon (dark circle)
    ctx.fillStyle = '#000000';
    ctx.beginPath();
    ctx.arc(x, y, size * 0.25, 0, Math.PI * 2);
    ctx.fill();
  }

  // CRYSTAL DEPTHS / PRESSURE ZONE: Recently collapsed stars
  private renderStellarBlackhole(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, phase: number) {
    // Circular accretion disk with blue crystalline patterns
    const diskRadius = size * 0.5;
    for (let ring = 0; ring < 4; ring++) {
      const radius = diskRadius * (0.4 + ring * 0.2);
      const brightness = 0.7 - ring * 0.1 + Math.sin(phase + ring) * 0.15;
      
      ctx.fillStyle = `rgba(100, 150, 255, ${Math.max(0, brightness)})`;
      ctx.beginPath();
      ctx.arc(x, y, radius, 0, Math.PI * 2);
      ctx.fill();
    }
    
    // Event horizon (dark circle)
    ctx.fillStyle = '#000000';
    ctx.beginPath();
    ctx.arc(x, y, size * 0.2, 0, Math.PI * 2);
    ctx.fill();
  }

  // DEEP SPACE: Ancient supermassive black holes
  private renderSupermassiveBlackhole(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, phase: number) {
    // Massive circular accretion disk with multiple layers
    const diskRadius = size * 0.8;
    for (let ring = 0; ring < 8; ring++) {
      const radius = diskRadius * (0.3 + ring * 0.1);
      const brightness = 0.9 - ring * 0.08 + Math.sin(phase * 0.5 + ring) * 0.15;
      
      ctx.fillStyle = `rgba(150, 100, 255, ${Math.max(0, brightness)})`;
      ctx.beginPath();
      ctx.arc(x, y, radius, 0, Math.PI * 2);
      ctx.fill();
    }
    
    // Large event horizon (dark circle)
    ctx.fillStyle = '#000000';
    ctx.beginPath();
    ctx.arc(x, y, size * 0.3, 0, Math.PI * 2);
    ctx.fill();
  }

  // MISTY VOID: Ancient primordial black holes
  private renderPrimordialBlackhole(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, phase: number) {
    // Ancient, fading circular accretion disk
    const diskRadius = size * 0.45;
    for (let ring = 0; ring < 5; ring++) {
      const radius = diskRadius * (0.4 + ring * 0.15);
      const brightness = 0.5 - ring * 0.08 + Math.sin(phase * 0.8 + ring) * 0.12;
      
      ctx.fillStyle = `rgba(120, 120, 180, ${Math.max(0, brightness)})`;
      ctx.beginPath();
      ctx.arc(x, y, radius, 0, Math.PI * 2);
      ctx.fill();
    }
    
    // Event horizon (dark circle)
    ctx.fillStyle = '#000000';
    ctx.beginPath();
    ctx.arc(x, y, size * 0.18, 0, Math.PI * 2);
    ctx.fill();
  }

  // MEMORY FIELDS / TERMINAL STATION: Information black holes
  private renderDataBlackhole(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, phase: number) {
    // Circular data accretion disk with digital patterns
    const diskRadius = size * 0.55;
    for (let ring = 0; ring < 6; ring++) {
      const radius = diskRadius * (0.35 + ring * 0.12);
      const brightness = 0.7 - ring * 0.1 + Math.sin(phase * 2 + ring) * 0.2;
      
      ctx.fillStyle = `rgba(255, 100, 255, ${Math.max(0, brightness)})`;
      ctx.beginPath();
      ctx.arc(x, y, radius, 0, Math.PI * 2);
      ctx.fill();
    }
    
    // Event horizon (dark circle)
    ctx.fillStyle = '#000000';
    ctx.beginPath();
    ctx.arc(x, y, size * 0.22, 0, Math.PI * 2);
    ctx.fill();
  }

  // PHASE SHIFTER: Quantum black holes phasing between dimensions
  private renderQuantumBlackhole(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, phase: number) {
    // Phase in and out of existence
    const phaseOpacity = 0.6 + Math.sin(phase * 3) * 0.4;
    
    // Quantum circular accretion disk
    const diskRadius = size * 0.5;
    for (let ring = 0; ring < 4; ring++) {
      const radius = diskRadius * (0.4 + ring * 0.15);
      const brightness = phaseOpacity * (0.8 - ring * 0.15 + Math.sin(phase * 2 + ring) * 0.2);
      
      ctx.fillStyle = `rgba(200, 100, 255, ${Math.max(0, brightness)})`;
      ctx.beginPath();
      ctx.arc(x, y, radius, 0, Math.PI * 2);
      ctx.fill();
    }
    
    // Phasing event horizon
    ctx.fillStyle = `rgba(0, 0, 0, ${phaseOpacity})`;
    ctx.beginPath();
    ctx.arc(x, y, size * 0.2, 0, Math.PI * 2);
    ctx.fill();
  }

  // RESISTANCE NEBULA: Small weapons-grade black holes
  private renderMicroBlackhole(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, phase: number) {
    // Small circular accretion disk with intense energy
    const diskRadius = size * 0.4;
    for (let ring = 0; ring < 3; ring++) {
      const radius = diskRadius * (0.5 + ring * 0.25);
      const brightness = 0.9 - ring * 0.2 + Math.sin(phase * 4 + ring) * 0.1;
      
      ctx.fillStyle = `rgba(255, 80, 80, ${Math.max(0, brightness)})`;
      ctx.beginPath();
      ctx.arc(x, y, radius, 0, Math.PI * 2);
      ctx.fill();
    }
    
    // Small event horizon
    ctx.fillStyle = '#000000';
    ctx.beginPath();
    ctx.arc(x, y, size * 0.15, 0, Math.PI * 2);
    ctx.fill();
  }

  private renderStardust(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, phase: number) {
    for (let i = 0; i < 15; i++) {
      const angle = (i / 15) * Math.PI * 2 + phase;
      const radius = (Math.random() * size * 0.4);
      const dustX = x + Math.cos(angle) * radius;
      const dustY = y + Math.sin(angle) * radius;
      
      const hue = (phase * 180 + i * 24) % 360;
      const brightness = 0.5 + Math.sin(phase + i) * 0.3;
      
      ctx.fillStyle = `hsla(${hue}, 80%, 60%, ${brightness})`;
      ctx.fillRect(dustX - 1, dustY - 1, 2, 2);
    }
  }

  private renderMatrix(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, phase: number) {
    const gridSize = 8;
    const cellSize = size / gridSize;
    
    for (let i = 0; i < gridSize; i++) {
      for (let j = 0; j < gridSize; j++) {
        const cellX = x - size/2 + i * cellSize;
        const cellY = y - size/2 + j * cellSize;
        const brightness = 0.3 + Math.sin(phase + i + j) * 0.4;
        
        if (brightness > 0.5) {
          ctx.strokeStyle = `rgba(0, 255, 100, ${brightness})`;
          ctx.lineWidth = 1;
          ctx.strokeRect(cellX, cellY, cellSize, cellSize);
        }
      }
    }
  }

  // WAR ZONE: Massive space carrier
  private renderSpaceship(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, phase: number, color: string) {
    ctx.strokeStyle = color;
    ctx.fillStyle = color.replace(')', ', 0.3)').replace('rgb', 'rgba');
    ctx.lineWidth = 2;
    
    // Main hull
    ctx.fillRect(x - size/2, y - size/6, size, size/3);
    ctx.strokeRect(x - size/2, y - size/6, size, size/3);
    
    // Bridge tower
    ctx.fillRect(x - size/4, y - size/4, size/2, size/8);
    
    // Engine glow
    const glowIntensity = 0.5 + Math.sin(phase * 2) * 0.3;
    ctx.fillStyle = `rgba(255, 100, 100, ${glowIntensity})`;
    ctx.fillRect(x - size/2 - 10, y - size/12, 8, size/6);
  }

  // WAR ZONE: Fast fighter ships
  private renderFighter(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, phase: number, color: string) {
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    
    // Fighter body
    ctx.beginPath();
    ctx.moveTo(x + size/2, y);
    ctx.lineTo(x - size/2, y - size/4);
    ctx.lineTo(x - size/3, y);
    ctx.lineTo(x - size/2, y + size/4);
    ctx.closePath();
    ctx.stroke();
    
    // Engine trail
    const trailLength = 15 + Math.sin(phase * 3) * 10;
    ctx.strokeStyle = `rgba(255, 150, 0, 0.8)`;
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(x - size/2, y);
    ctx.lineTo(x - size/2 - trailLength, y);
    ctx.stroke();
  }

  // WAR ZONE: Laser beams
  private renderLaser(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, phase: number, color: string) {
    const pulseIntensity = 0.7 + Math.sin(phase * 5) * 0.3;
    ctx.strokeStyle = color.replace(')', `, ${pulseIntensity})`).replace('rgb', 'rgba');
    ctx.lineWidth = size/2;
    
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + size * 3, y);
    ctx.stroke();
    
    // Laser glow
    ctx.strokeStyle = `rgba(255, 255, 255, ${pulseIntensity * 0.5})`;
    ctx.lineWidth = 2;
    ctx.stroke();
  }

  // CRYSTAL DEPTHS: Floating crystals
  private renderCrystal(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, phase: number, color: string) {
    const glowIntensity = 0.6 + Math.sin(phase * 1.5) * 0.4;
    
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(phase * 0.5);
    
    // Crystal structure
    ctx.strokeStyle = color;
    ctx.fillStyle = color.replace(')', ', 0.2)').replace('rgb', 'rgba');
    ctx.lineWidth = 2;
    
    const points = 6;
    ctx.beginPath();
    for (let i = 0; i < points; i++) {
      const angle = (i / points) * Math.PI * 2;
      const radius = size/2 * (0.8 + Math.sin(phase + i) * 0.2);
      const px = Math.cos(angle) * radius;
      const py = Math.sin(angle) * radius;
      
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    
    // Inner glow
    ctx.fillStyle = `rgba(100, 200, 255, ${glowIntensity})`;
    ctx.beginPath();
    ctx.arc(0, 0, size/4, 0, Math.PI * 2);
    ctx.fill();
    
    ctx.restore();
  }

  // DIGITAL ECONOMY: Data streams
  private renderDataStream(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, phase: number, color: string) {
    const segments = 8;
    const segmentSize = size / segments;
    
    for (let i = 0; i < segments; i++) {
      const segmentPhase = phase + i * 0.5;
      const alpha = 0.3 + Math.sin(segmentPhase) * 0.7;
      const segmentY = y + (i - segments/2) * segmentSize;
      
      ctx.fillStyle = color.replace(')', `, ${alpha})`).replace('rgb', 'rgba');
      ctx.fillRect(x - size/8, segmentY, size/4, segmentSize * 0.8);
    }
  }

  // DIGITAL ECONOMY: Cyber towers
  private renderTower(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, phase: number, color: string) {
    const levels = 4;
    const levelHeight = size / levels;
    
    for (let i = 0; i < levels; i++) {
      const levelY = y + (i - levels/2) * levelHeight;
      const levelWidth = size * (0.8 - i * 0.1);
      const levelAlpha = 0.4 + Math.sin(phase + i) * 0.3;
      
      ctx.fillStyle = color.replace(')', `, ${levelAlpha})`).replace('rgb', 'rgba');
      ctx.strokeStyle = color;
      ctx.lineWidth = 1;
      
      ctx.fillRect(x - levelWidth/2, levelY, levelWidth, levelHeight * 0.8);
      ctx.strokeRect(x - levelWidth/2, levelY, levelWidth, levelHeight * 0.8);
      
      // Tower lights
      if (Math.sin(phase * 2 + i) > 0.5) {
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(x - 2, levelY + levelHeight/4, 4, 2);
      }
    }
  }

  // Render laser battles between ships
  private renderLasers(ctx: CanvasRenderingContext2D) {
    for (const laser of this.lasers) {
      const alpha = Math.min(1, laser.life / 500); // Fade out over 0.5 seconds
      ctx.strokeStyle = `rgba(255, 51, 51, ${alpha})`;
      ctx.lineWidth = 3;
      
      ctx.beginPath();
      ctx.moveTo(laser.x, laser.y);
      ctx.lineTo(laser.targetX, laser.targetY);
      ctx.stroke();
      
      // Add glow effect
      ctx.strokeStyle = `rgba(255, 255, 255, ${alpha * 0.5})`;
      ctx.lineWidth = 1;
      ctx.stroke();
    }
  }

  // WAR ZONE: Enhanced massive carriers
  private renderCarrier(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, phase: number, color: string) {
    ctx.strokeStyle = color;
    ctx.fillStyle = color.replace(')', ', 0.3)').replace('rgb', 'rgba');
    ctx.lineWidth = 3;
    
    // Main carrier hull - larger and more detailed
    ctx.fillRect(x - size/2, y - size/4, size, size/2);
    ctx.strokeRect(x - size/2, y - size/4, size, size/2);
    
    // Command bridge
    ctx.fillRect(x - size/3, y - size/3, size/1.5, size/6);
    
    // Fighter bay openings
    ctx.fillStyle = '#000000';
    ctx.fillRect(x - size/2 + 10, y - size/8, size/8, size/16);
    ctx.fillRect(x - size/2 + 10, y + size/16, size/8, size/16);
    
    // Engine glow - multiple engines
    const glowIntensity = 0.7 + Math.sin(phase * 3) * 0.3;
    ctx.fillStyle = `rgba(255, 120, 60, ${glowIntensity})`;
    ctx.fillRect(x - size/2 - 15, y - size/6, 12, size/12);
    ctx.fillRect(x - size/2 - 15, y + size/12, 12, size/12);
  }

  // WAR ZONE: Smaller battleships
  private renderBattleship(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, phase: number, color: string) {
    ctx.strokeStyle = color;
    ctx.fillStyle = color.replace(')', ', 0.4)').replace('rgb', 'rgba');
    ctx.lineWidth = 2;
    
    // Main hull
    ctx.fillRect(x - size/2, y - size/6, size, size/3);
    ctx.strokeRect(x - size/2, y - size/6, size, size/3);
    
    // Weapon turrets
    ctx.fillStyle = '#666666';
    ctx.fillRect(x - size/4, y - size/8, size/8, size/8);
    ctx.fillRect(x + size/8, y - size/8, size/8, size/8);
    
    // Engine trail
    const glowIntensity = 0.6 + Math.sin(phase * 2.5) * 0.4;
    ctx.fillStyle = `rgba(255, 100, 40, ${glowIntensity})`;
    ctx.fillRect(x - size/2 - 10, y - size/12, 8, size/6);
  }

  // WAR ZONE: Explosions
  private renderExplosion(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, phase: number, color: string) {
    const intensity = Math.sin(phase * 5) * 0.5 + 0.5;
    
    // Multiple explosion rings
    for (let i = 0; i < 4; i++) {
      const ringSize = size * (0.3 + i * 0.2) * intensity;
      const alpha = (1 - i * 0.2) * intensity;
      
      ctx.fillStyle = `rgba(255, ${100 - i * 20}, ${50 - i * 10}, ${alpha})`;
      ctx.beginPath();
      ctx.arc(x, y, ringSize, 0, Math.PI * 2);
      ctx.fill();
    }
    
    // Explosion particles
    for (let i = 0; i < 8; i++) {
      const angle = (i / 8) * Math.PI * 2 + phase;
      const distance = size * intensity * 0.8;
      const px = x + Math.cos(angle) * distance;
      const py = y + Math.sin(angle) * distance;
      
      ctx.fillStyle = `rgba(255, 150, 0, ${intensity})`;
      ctx.fillRect(px - 2, py - 2, 4, 4);
    }
  }

  // CRYSTAL DEPTHS: Crystal shards
  private renderCrystalShard(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, phase: number, color: string) {
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(phase);
    
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    
    // Sharp crystal shard shape
    ctx.beginPath();
    ctx.moveTo(0, -size/2);
    ctx.lineTo(size/4, 0);
    ctx.lineTo(0, size/2);
    ctx.lineTo(-size/4, 0);
    ctx.closePath();
    ctx.stroke();
    
    // Inner glow
    const glowIntensity = 0.4 + Math.sin(phase * 2) * 0.3;
    ctx.fillStyle = color.replace(')', `, ${glowIntensity})`).replace('rgb', 'rgba');
    ctx.fill();
    
    ctx.restore();
  }

  // CRYSTAL DEPTHS: Energy fields
  private renderEnergyField(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, phase: number, color: string) {
    const pulseIntensity = 0.3 + Math.sin(phase * 1.5) * 0.4;
    
    // Energy field waves
    for (let i = 0; i < 3; i++) {
      const waveSize = size * (0.6 + i * 0.2);
      const alpha = (0.8 - i * 0.2) * pulseIntensity;
      
      ctx.strokeStyle = color.replace(')', `, ${alpha})`).replace('rgb', 'rgba');
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(x, y, waveSize, 0, Math.PI * 2);
      ctx.stroke();
    }
  }

  // DIGITAL/SYNC: Code rain
  private renderCodeRain(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, phase: number, color: string) {
    const characters = ['0', '1', '{', '}', '<', '>', '/', '\\'];
    
    for (let i = 0; i < 6; i++) {
      const charX = x + (i - 3) * size/4;
      const charY = y + Math.sin(phase + i) * size/3;
      const alpha = 0.5 + Math.sin(phase * 2 + i) * 0.3;
      
      ctx.fillStyle = color.replace(')', `, ${alpha})`).replace('rgb', 'rgba');
      ctx.font = `${size/4}px monospace`;
      ctx.fillText(characters[i % characters.length], charX, charY);
    }
  }

  // TOXIC: Toxic clouds
  private renderToxicCloud(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, phase: number, color: string) {
    const cloudParts = 5;
    
    for (let i = 0; i < cloudParts; i++) {
      const partX = x + Math.sin(phase + i) * size/4;
      const partY = y + Math.cos(phase + i * 0.7) * size/6;
      const partSize = size * (0.3 + Math.sin(phase + i) * 0.2);
      const alpha = 0.3 + Math.sin(phase * 1.5 + i) * 0.2;
      
      ctx.fillStyle = color.replace(')', `, ${alpha})`).replace('rgb', 'rgba');
      ctx.beginPath();
      ctx.arc(partX, partY, partSize, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  // TOXIC: Acid rain
  private renderAcidRain(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, phase: number, color: string) {
    const drops = 8;
    
    for (let i = 0; i < drops; i++) {
      const dropX = x + (i - drops/2) * size/4;
      const dropY = y + Math.sin(phase * 3 + i) * size;
      const alpha = 0.6 + Math.sin(phase * 2 + i) * 0.4;
      
      ctx.strokeStyle = color.replace(')', `, ${alpha})`).replace('rgb', 'rgba');
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(dropX, dropY);
      ctx.lineTo(dropX, dropY + size/2);
      ctx.stroke();
    }
  }

  // MEMORY: Memory fragments
  private renderMemoryFragment(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, phase: number, color: string) {
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(phase * 0.5);
    
    const alpha = 0.5 + Math.sin(phase * 2) * 0.3;
    ctx.strokeStyle = color.replace(')', `, ${alpha})`).replace('rgb', 'rgba');
    ctx.lineWidth = 2;
    
    // Fragmented square
    ctx.strokeRect(-size/4, -size/4, size/2, size/2);
    ctx.strokeRect(-size/6, -size/6, size/3, size/3);
    
    // Memory bits
    for (let i = 0; i < 4; i++) {
      const bitX = Math.cos(i * Math.PI/2 + phase) * size/3;
      const bitY = Math.sin(i * Math.PI/2 + phase) * size/3;
      ctx.fillStyle = color.replace(')', `, ${alpha * 0.8})`).replace('rgb', 'rgba');
      ctx.fillRect(bitX - 2, bitY - 2, 4, 4);
    }
    
    ctx.restore();
  }

  // MEMORY: Data ghosts
  private renderDataGhost(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, phase: number, color: string) {
    const ghostAlpha = 0.2 + Math.sin(phase) * 0.3;
    
    // Ghostly form
    ctx.fillStyle = color.replace(')', `, ${ghostAlpha})`).replace('rgb', 'rgba');
    ctx.beginPath();
    ctx.arc(x, y - size/4, size/3, 0, Math.PI * 2);
    ctx.fill();
    
    // Trailing wisps
    for (let i = 0; i < 3; i++) {
      const wispY = y + i * size/6;
      const wispSize = size/4 * (1 - i * 0.3);
      const wispAlpha = ghostAlpha * (1 - i * 0.3);
      
      ctx.fillStyle = color.replace(')', `, ${wispAlpha})`).replace('rgb', 'rgba');
      ctx.beginPath();
      ctx.arc(x, wispY, wispSize, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  // PARADISE: Energy wisps
  private renderEnergyWisp(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, phase: number, color: string) {
    const wispIntensity = 0.4 + Math.sin(phase * 1.8) * 0.4;
    
    // Wisp trail
    for (let i = 0; i < 6; i++) {
      const trailX = x + Math.sin(phase + i * 0.5) * size/4;
      const trailY = y + i * size/8;
      const trailSize = size/4 * (1 - i * 0.15);
      const alpha = wispIntensity * (1 - i * 0.15);
      
      ctx.fillStyle = color.replace(')', `, ${alpha})`).replace('rgb', 'rgba');
      ctx.beginPath();
      ctx.arc(trailX, trailY, trailSize, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  // PARADISE: Floating gardens
  private renderFloatingGarden(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, phase: number, color: string) {
    // Garden base
    const alpha = 0.6 + Math.sin(phase) * 0.2;
    ctx.fillStyle = color.replace(')', `, ${alpha})`).replace('rgb', 'rgba');
    ctx.fillRect(x - size/2, y - size/6, size, size/3);
    
    // Growing plants
    for (let i = 0; i < 4; i++) {
      const plantX = x - size/3 + i * size/6;
      const plantHeight = size/4 + Math.sin(phase + i) * size/8;
      
      ctx.strokeStyle = '#66ff66';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(plantX, y);
      ctx.lineTo(plantX, y - plantHeight);
      ctx.stroke();
      
      // Leaves
      ctx.fillStyle = `rgba(102, 255, 102, 0.7)`;
      ctx.beginPath();
      ctx.arc(plantX, y - plantHeight, size/16, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  changeTheme() {
    // Flash effect on collision
    this.themeTransition = 0.5;
    console.log('Background flash effect triggered');
  }

  private renderSecretLevel(ctx: CanvasRenderingContext2D) {
    // Secret level background - deep space with nebula collision
    const gradient = ctx.createRadialGradient(
      this.canvasWidth / 2, this.canvasHeight / 2, 0,
      this.canvasWidth / 2, this.canvasHeight / 2, Math.max(this.canvasWidth, this.canvasHeight)
    );
    gradient.addColorStop(0, '#000033');
    gradient.addColorStop(0.5, '#000011');
    gradient.addColorStop(1, '#000000');
    
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, this.canvasWidth, this.canvasHeight);
    
    // Render fast-moving starfield
    for (const star of this.stars) {
      const brightness = 0.8 + Math.sin(this.secretLevelTime * star.brightness * 0.002) * 0.2;
      ctx.fillStyle = `rgba(255, 255, 255, ${brightness})`;
      
      if (star.size > 1) {
        // Large star with cross pattern (more prominent in secret level)
        ctx.fillRect(star.x - 2, star.y, 4, 1);
        ctx.fillRect(star.x, star.y - 2, 1, 4);
      } else {
        // Small star
        ctx.fillRect(star.x, star.y, 1, 1);
      }
    }
    
    // Render nebula collision
    const collapseProgress = Math.min(this.secretLevelTime / 25000, 1);
    for (const nebula of this.nebulaStars) {
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      
      // Create nebula glow effect that intensifies as they get closer
      const intensity = 1 + collapseProgress * 2;
      const gradient = ctx.createRadialGradient(
        nebula.x, nebula.y, 0,
        nebula.x, nebula.y, nebula.size * intensity
      );
      gradient.addColorStop(0, nebula.color);
      gradient.addColorStop(0.3, `${nebula.color}80`);
      gradient.addColorStop(0.8, `${nebula.color}20`);
      gradient.addColorStop(1, 'transparent');
      
      ctx.fillStyle = gradient;
      ctx.fillRect(
        nebula.x - nebula.size * intensity, 
        nebula.y - nebula.size * intensity,
        nebula.size * intensity * 2, 
        nebula.size * intensity * 2
      );
      
      ctx.restore();
    }
    
    // Render Eclipse Expedition starship being pulled into black hole
    // CPU Optimization: Only process starship when visible and active
    if (this.starshipLoaded && this.starshipImage && collapseProgress > 0.05 && collapseProgress < 1.0) {
      const centerX = this.canvasWidth / 2;
      const centerY = this.canvasHeight / 2;
      
      // Continuous motion: Ship enters late but flows smoothly into black hole pull
      // Single continuous trajectory from off-screen to black hole center
      const totalProgress = Math.min((collapseProgress - 0.2) / 0.8, 1); // Start at 20%, end at 100%
      
      if (totalProgress > 0) {
        // Continuous path from off-screen right to black hole center
        const startX = this.canvasWidth + 150; // Start well off-screen
        const startY = this.canvasHeight * 0.7;
        
        // Smooth continuous easing - slow start, accelerating toward black hole
        const smoothProgress = totalProgress * totalProgress; // Quadratic easing for smooth acceleration
        
        this.starshipX = startX + (centerX - startX) * smoothProgress;
        this.starshipY = startY + (centerY - startY) * smoothProgress;
        
        // Scale down as it gets closer to black hole
        this.starshipScale = 0.8 * (1 - smoothProgress * 0.7);
        
        // Rotation: starts with gentle banking, increases to dramatic spin
        const rotationIntensity = smoothProgress < 0.3 ? smoothProgress * 0.5 : 0.15 + (smoothProgress - 0.3) * 8;
        this.starshipRotation = -rotationIntensity * Math.PI;
      }
      
      // Fade out near the end
      const alpha = totalProgress > 0.9 ? 1 - (totalProgress - 0.9) / 0.1 : 1;
      
      // Create boost trail particles from afterburners (right side of ship since it faces left)
      // Light trails during entry, intensifying as black hole pull increases
      const boostIntensity = totalProgress < 0.3 ? totalProgress * 0.3 : totalProgress;
      this.createStarshipBoostTrail(boostIntensity, 16.67); // Use fixed deltaTime for consistency
      
      // Render boost trail particles first (behind the ship)
      this.renderStarshipBoostTrail(ctx, alpha);
      
      ctx.save();
      ctx.globalAlpha = alpha;
      ctx.translate(this.starshipX, this.starshipY);
      ctx.rotate(this.starshipRotation);
      ctx.scale(this.starshipScale, this.starshipScale);
      
      // Draw the starship centered
      const shipWidth = this.starshipImage.width * 0.3; // Scale down the image
      const shipHeight = this.starshipImage.height * 0.3;
      ctx.drawImage(
        this.starshipImage,
        -shipWidth / 2,
        -shipHeight / 2,
        shipWidth,
        shipHeight
      );
      
      ctx.restore();
    }
    
    // Create black hole effect when nebulae fully collapse
    if (collapseProgress > 0.7) {
      const centerX = this.canvasWidth / 2;
      const centerY = this.canvasHeight / 2;
      const blackHoleProgress = (collapseProgress - 0.7) / 0.3; // 0 to 1 over final 30%
      const blackHoleSize = blackHoleProgress * 150;
      
      ctx.save();
      ctx.globalCompositeOperation = 'multiply';
      
      // Black hole center
      const blackHole = ctx.createRadialGradient(
        centerX, centerY, 0,
        centerX, centerY, blackHoleSize
      );
      blackHole.addColorStop(0, 'black');
      blackHole.addColorStop(0.3, '#000033');
      blackHole.addColorStop(0.6, '#001133');
      blackHole.addColorStop(1, 'transparent');
      
      ctx.fillStyle = blackHole;
      ctx.fillRect(
        centerX - blackHoleSize, centerY - blackHoleSize,
        blackHoleSize * 2, blackHoleSize * 2
      );
      
      ctx.restore();
      
      // Accretion disk effect
      if (blackHoleProgress > 0.3) {
        ctx.save();
        ctx.globalCompositeOperation = 'screen';
        
        const diskRadius = blackHoleSize * 2;
        const diskGradient = ctx.createRadialGradient(
          centerX, centerY, blackHoleSize * 0.6,
          centerX, centerY, diskRadius
        );
        diskGradient.addColorStop(0, 'transparent');
        diskGradient.addColorStop(0.3, '#ff440020');
        diskGradient.addColorStop(0.7, '#4488ff20');
        diskGradient.addColorStop(1, 'transparent');
        
        ctx.fillStyle = diskGradient;
        ctx.fillRect(
          centerX - diskRadius, centerY - diskRadius,
          diskRadius * 2, diskRadius * 2
        );
        
        ctx.restore();
      }
    }
    
    // Theme transition flash effect
    if (this.themeTransition > 0) {
      ctx.fillStyle = `rgba(255, 255, 255, ${this.themeTransition})`;
      ctx.fillRect(0, 0, this.canvasWidth, this.canvasHeight);
    }
  }
  
  private loadStarshipImage() {
    this.starshipImage = new Image();
    this.starshipImage.onload = () => {
      this.starshipLoaded = true;
      console.log('Eclipse Expedition starship loaded for secret level');
    };
    this.starshipImage.onerror = () => {
      console.warn('Failed to load starship image');
    };
    this.starshipImage.src = '/images/eclipse-expedition.png';
  }

  private createStarshipBoostTrail(pullProgress: number, deltaTime: number) {
    // Update existing boost particles
    for (let i = this.starshipBoostParticles.length - 1; i >= 0; i--) {
      const particle = this.starshipBoostParticles[i];
      particle.life -= 16.67; // Use fixed deltaTime for consistency
      
      // Move particles
      particle.x += particle.vx * 0.01667; // Convert deltaTime to seconds
      particle.y += particle.vy * 0.01667;
      
      // Apply slight gravity effect towards black hole center
      const centerX = this.canvasWidth / 2;
      const centerY = this.canvasHeight / 2;
      const gravityStrength = pullProgress * 0.1;
      const dx = centerX - particle.x;
      const dy = centerY - particle.y;
      const dist = Math.sqrt(dx * dx + dy * dy);
      
      if (dist > 0) {
        particle.vx += (dx / dist) * gravityStrength * 0.01667;
        particle.vy += (dy / dist) * gravityStrength * 0.01667;
      }
      
      // Remove dead particles
      if (particle.life <= 0) {
        this.starshipBoostParticles.splice(i, 1);
      }
    }
    
    // Create new boost particles from afterburners - intensity increases as ship struggles
    const boostIntensity = Math.min(pullProgress * 3, 1); // Intensify as it gets pulled
    const particleCount = Math.floor(boostIntensity * 8 + 2); // More particles when struggling
    
    for (let i = 0; i < particleCount; i++) {
      if (Math.random() < 0.7) { // 70% chance to spawn particle each frame
        // Calculate afterburner position (right side of ship since it faces left)
        const shipWidth = (this.starshipImage?.width || 200) * 0.3 * this.starshipScale;
        const shipHeight = (this.starshipImage?.height || 100) * 0.3 * this.starshipScale;
        
        // Afterburner positions (right side, slightly offset for multiple engines)
        const afterburnerOffset = shipWidth * 0.4; // Right side of ship
        const engineSpread = shipHeight * 0.2; // Multiple engine positions
        
        // Transform afterburner position based on ship rotation
        const offsetX = Math.cos(this.starshipRotation) * afterburnerOffset;
        const offsetY = Math.sin(this.starshipRotation) * afterburnerOffset;
        
        const engineY = (Math.random() - 0.5) * engineSpread;
        const engineOffsetX = Math.cos(this.starshipRotation + Math.PI/2) * engineY;
        const engineOffsetY = Math.sin(this.starshipRotation + Math.PI/2) * engineY;
        
        const startX = this.starshipX + offsetX + engineOffsetX;
        const startY = this.starshipY + offsetY + engineOffsetY;
        
        // Boost direction opposite to ship facing (ship faces left, boost goes right)
        // But also gets affected by black hole pull
        const baseVx = 100 + Math.random() * 50; // Base rightward velocity
        const baseVy = (Math.random() - 0.5) * 30; // Small random vertical component
        
        // Transform velocity based on ship rotation
        const boostVx = Math.cos(this.starshipRotation) * baseVx - Math.sin(this.starshipRotation) * baseVy;
        const boostVy = Math.sin(this.starshipRotation) * baseVx + Math.cos(this.starshipRotation) * baseVy;
        
        this.starshipBoostParticles.push({
          x: startX,
          y: startY,
          vx: boostVx,
          vy: boostVy,
          life: 800 + Math.random() * 400, // 0.8-1.2 seconds
          maxLife: 1200,
          size: 2 + Math.random() * 3 + boostIntensity * 2, // Bigger when struggling
          color: Math.random() < 0.7 ? '#00aaff' : '#0088cc' // Blue thrust colors
        });
      }
    }
  }

  private renderStarshipBoostTrail(ctx: CanvasRenderingContext2D, shipAlpha: number) {
    for (const particle of this.starshipBoostParticles) {
      const lifeRatio = particle.life / particle.maxLife;
      const alpha = lifeRatio * shipAlpha * 0.8;
      
      ctx.save();
      ctx.globalAlpha = alpha;
      ctx.globalCompositeOperation = 'screen';
      
      // Create gradient for boost particle
      const gradient = ctx.createRadialGradient(
        particle.x, particle.y, 0,
        particle.x, particle.y, particle.size * 2
      );
      gradient.addColorStop(0, particle.color);
      gradient.addColorStop(0.5, particle.color + '80');
      gradient.addColorStop(1, 'transparent');
      
      ctx.fillStyle = gradient;
      ctx.fillRect(
        particle.x - particle.size * 2,
        particle.y - particle.size * 2,
        particle.size * 4,
        particle.size * 4
      );
      
      ctx.restore();
    }
  }

  reset() {
    this.currentSector = 'misty';
    this.themeTransition = 0;
    this.sectorProgress = 0;
    this.cosmicObjects = [];
    this.generateStars();
    this.isSecretLevel = false;
    this.secretLevelTime = 0;
    
    // Reset starship position for secret level
    this.starshipX = this.canvasWidth + 150; // Start off-screen to the right
    this.starshipY = this.canvasHeight * 0.7; // Lower part of screen
    this.starshipScale = 0.8;
    this.starshipRotation = 0;
    this.starshipBoostParticles = [];
  }

  getCurrentSector(): SpaceSector {
    return this.currentSector;
  }

  getSectorProgress(): number {
    return this.sectorProgress;
  }
}
