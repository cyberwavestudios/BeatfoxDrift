import { Background } from './background';
import { BeatfoxSprite } from './sprites';
import { ParticleSystem } from './particles';
import { ObstacleManager } from './obstacles';
import { CollisionDetector } from './collision';
import { useGameState } from './stores/useGameState';
import { useAudio } from './stores/useAudio';

export class GameEngine {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private isRunning: boolean = false;
  private lastTime: number = 0;
  
  // Game objects
  private background: Background;
  private player: BeatfoxSprite;
  private particles: ParticleSystem;
  private obstacles: ObstacleManager;
  private collision: CollisionDetector;
  
  // Game state will be accessed dynamically
  
  // Input handling
  private keys: Set<string> = new Set();
  private touchMovement = { x: 0, y: 0 };
  
  // Scoring
  private scoreTimer: number = 0;
  private difficultyTimer: number = 0;
  
  // Sector tracking for future features
  private sectorCollisions: number = 0;
  private lastCompletedSector: string = ''; // Track last completed sector to prevent duplicates
  private lastTrackName: string = ''; // Track last track name for music changes
  private secretLevelTriggered: boolean = false; // Prevent multiple secret level triggers
  
  // Cached dimensions for performance
  private gameWidth: number = 0;
  private gameHeight: number = 0;
  private resizeTimer: number | null = null;
  
  // Orientation lock for mobile
  private isLandscapeBlocked: boolean = false;
  
  // Epic ending autopilot mode
  private isAutopilotMode: boolean = false;
  private autopilotStartTime: number = 0;
  private orbitingCrystals: {
    angle: number;
    radius: number;
    color: string;
    glow: string;
    name: string;
  }[] = [];
  private secretLevelCompleted: boolean = false;
  private epicEndingTriggered: boolean = false; // Prevent multiple triggers

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d')!;
    this.ctx.imageSmoothingEnabled = false;
    
    // Initialize sector tracking
    this.sectorCollisions = 0;
    this.lastCompletedSector = '';
    this.lastTrackName = '';
    
    // Get and cache display dimensions for game logic
    this.updateDimensions();
    
    // Initialize game objects with proper dimensions
    this.background = new Background(this.gameWidth, this.gameHeight);
    this.player = new BeatfoxSprite(100, this.gameHeight / 2);
    this.particles = new ParticleSystem();
    this.obstacles = new ObstacleManager(this.gameWidth, this.gameHeight);
    this.collision = new CollisionDetector();
    
    this.setupEventListeners();
    this.checkOrientation(); // Initial orientation check
    console.log('GameEngine initialized with dimensions:', this.gameWidth, 'x', this.gameHeight);
    console.log('Game engine initialized');
  }

  private handleKeyDown = (e: KeyboardEvent) => {
    this.keys.add(e.code);
    
    const gameState = useGameState.getState();
    
    // Reserved for future features (shift/space now available)
    
    // Start game only when instructions are dismissed
    if ((e.code === 'Space' || e.code === 'Enter') && gameState.gamePhase === 'ready') {
      // Don't auto-start, let the UI handle it
    }
    
    console.log('Key pressed:', e.code);
  };

  private handleKeyUp = (e: KeyboardEvent) => {
    this.keys.delete(e.code);
  };

  private updateDimensions() {
    try {
      const rect = this.canvas.getBoundingClientRect();
      
      // Safari iOS fix: Ensure we have valid dimensions
      if (rect.width === 0 || rect.height === 0) {
        console.warn('Canvas getBoundingClientRect returned 0 dimensions in GameEngine');
        this.gameWidth = Math.min(window.innerWidth * 0.9, 800);
        this.gameHeight = Math.min(window.innerHeight * 0.7, 600);
      } else {
        this.gameWidth = rect.width;
        this.gameHeight = rect.height;
      }
      
      console.log('GameEngine dimensions updated:', this.gameWidth, 'x', this.gameHeight);
    } catch (error) {
      console.warn('GameEngine updateDimensions failed, using fallback');
      this.gameWidth = Math.min(window.innerWidth * 0.9, 800);
      this.gameHeight = Math.min(window.innerHeight * 0.7, 600);
    }
  }
  
  private setupEventListeners() {
    window.addEventListener('keydown', this.handleKeyDown);
    window.addEventListener('keyup', this.handleKeyUp);
    window.addEventListener('resize', this.handleResize);
  }
  
  public handleResize = () => {
    // Debounce resize events for performance
    if (this.resizeTimer) {
      clearTimeout(this.resizeTimer);
    }
    this.resizeTimer = setTimeout(() => {
      const oldWidth = this.gameWidth;
      const oldHeight = this.gameHeight;
      
      this.updateDimensions();
      this.checkOrientation();
      
      // Only update game objects if dimensions changed significantly
      const widthChange = Math.abs(this.gameWidth - oldWidth);
      const heightChange = Math.abs(this.gameHeight - oldHeight);
      
      if (widthChange > 10 || heightChange > 10) {
        console.log('Significant dimension change detected, updating game objects');
        
        // Update game objects with new dimensions
        // Note: Background and ObstacleManager don't have resize methods
        // They automatically adapt to the canvas dimensions during rendering
        
        // Reset player position to be within new bounds with validation
        if (this.player && this.gameWidth > 0 && this.gameHeight > 0) {
          const maxX = Math.max(20, this.gameWidth - this.player.width - 20);
          const maxY = Math.max(20, this.gameHeight - this.player.height - 20);
          
          // Ensure player stays in valid area - fix for mobile distortion bug
          this.player.x = Math.max(20, Math.min(this.player.x, maxX));
          this.player.y = Math.max(20, Math.min(this.player.y, maxY));
          
          console.log('Player repositioned to:', this.player.x, this.player.y);
          console.log('Game bounds:', this.gameWidth, 'x', this.gameHeight);
        }
      }
      
      this.resizeTimer = null;
    }, 100) as any;
  };
  
  private checkOrientation() {
    // Check if we're on mobile and in landscape mode
    const isMobile = window.innerWidth <= 768 || /Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    this.isLandscapeBlocked = isMobile && window.innerWidth > window.innerHeight;
  }

  private removeEventListeners() {
    window.removeEventListener('keydown', this.handleKeyDown);
    window.removeEventListener('keyup', this.handleKeyUp);
    window.removeEventListener('resize', this.handleResize);
    if (this.resizeTimer) {
      clearTimeout(this.resizeTimer);
      this.resizeTimer = null;
    }
  }

  private startGame() {
    console.log('Starting game');
    const gameState = useGameState.getState();
    gameState.start();
    this.resetGame();
    
    // Initialize soundtrack if not already done
    const audioState = useAudio.getState();
    if (!audioState.isPlaylistInitialized) {
      audioState.initializeSoundtrack();
    }
  }

  private resetGame() {
    this.player.reset(100, this.gameHeight / 2);
    this.obstacles.reset();
    this.particles.clear();
    this.background.reset();
    this.scoreTimer = 0;
    this.difficultyTimer = 0;
    
    // Reset sector tracking
    this.sectorCollisions = 0;
    this.lastCompletedSector = '';
    
    console.log('Game reset, player position:', this.player.x, this.player.y);
  }

  private checkSectorCompletion() {
    const gameState = useGameState.getState();
    
    // Use the gameState collision count (which is the source of truth)
    const currentCollisions = gameState.currentSectorCollisions;
    console.log('Checking sector completion - Collisions in this sector:', currentCollisions);
    
    // Store collision count before resetting
    const hadPerfectSector = currentCollisions === 0;
    
    // Perfect sector completed
    if (hadPerfectSector) {
      console.log('Perfect sector completed!');
    } else {
      console.log('Sector completed with', currentCollisions, 'collisions - no crystal awarded');
    }
    
    // Complete the sector (will award crystal if perfect)
    gameState.completeSector();
    
    // Check for secret level unlock immediately after crystal award
    const newCrystalCount = gameState.cyberCrystals;
    if (newCrystalCount >= 7 && !gameState.isInSecretLevel && !this.secretLevelTriggered) {
      console.log('🌟 Secret level conditions met - will trigger on next frame');
      this.secretLevelTriggered = true;
      // Trigger on next frame to allow UI to update
      setTimeout(() => {
        if (gameState.cyberCrystals >= 7 && gameState.isPlaying && !gameState.isInSecretLevel) {
          this.triggerSecretLevel();
        }
      }, 100);
    }
    
    // Reset collision counter for next sector (both tracking systems)
    this.sectorCollisions = 0;
  }

  // Dash functionality removed - shift/space now available for future features

  private handleInput(deltaTime: number) {
    const gameState = useGameState.getState();
    if (!gameState.isPlaying || this.isLandscapeBlocked || this.isAutopilotMode) return;

    const speed = 250; // Consistent movement speed
    const normalizedSpeed = speed * (deltaTime * 0.001); // Pre-calculate division
    
    // Use cached dimensions instead of getBoundingClientRect
    const maxX = this.gameWidth - 80;
    const maxY = this.gameHeight - 60;

    // Keyboard movement controls
    if (this.keys.has('ArrowUp') || this.keys.has('KeyW')) {
      this.player.y = Math.max(20, this.player.y - normalizedSpeed);
    }
    if (this.keys.has('ArrowDown') || this.keys.has('KeyS')) {
      this.player.y = Math.min(maxY, this.player.y + normalizedSpeed);
    }
    if (this.keys.has('ArrowLeft') || this.keys.has('KeyA')) {
      this.player.x = Math.max(20, this.player.x - normalizedSpeed);
    }
    if (this.keys.has('ArrowRight') || this.keys.has('KeyD')) {
      this.player.x = Math.min(maxX, this.player.x + normalizedSpeed);
    }

    // Touch movement controls
    if (this.touchMovement.x !== 0 || this.touchMovement.y !== 0) {
      const touchSpeed = normalizedSpeed * 1.2; // Slightly faster for touch
      this.player.x = Math.max(20, Math.min(maxX, this.player.x + this.touchMovement.x * touchSpeed));
      this.player.y = Math.max(20, Math.min(maxY, this.player.y + this.touchMovement.y * touchSpeed));
    }
  }

  private updateGame(deltaTime: number) {
    const gameState = useGameState.getState();
    
    // Handle autopilot mode during epic ending (runs regardless of game state)
    if (this.isAutopilotMode) {
      this.updateAutopilotMode(deltaTime);
      return;
    }
    
    if (!gameState.isPlaying || this.isLandscapeBlocked) return;

    // Update timers
    this.scoreTimer += deltaTime;
    this.difficultyTimer += deltaTime;

    // Update score every second
    if (this.scoreTimer >= 1000) {
      gameState.incrementScore();
      this.scoreTimer = 0;
    }

    // Increase difficulty over time
    const difficultyLevel = Math.floor(this.difficultyTimer / 10000);
    
    // Update game objects with player position for interactive effects
    this.background.update(deltaTime, gameState.score, this.player.x, this.player.y);
    
    // Update background sector based on current music track
    const audioState = useAudio.getState();
    const currentSector = audioState.getCurrentSector();
    const previousSector = this.background.getCurrentSector();
    this.background.setSector(currentSector.name, currentSector.color);
    
    // Optimized track detection - cache track name to avoid repeated string operations
    const currentTrack = audioState.currentTrack;
    const currentTrackName = currentTrack ? 
      (currentTrack.src.split('/').pop()?.split('.')[0] || '') : '';
    
    const hasTrackChanged = this.lastTrackName && 
                          this.lastTrackName !== currentTrackName && 
                          currentTrackName; // Ensure valid track name
    
    
    // Only award crystals when music track actually changes after significant gameplay
    if (hasTrackChanged &&
        gameState.isPlaying && 
        gameState.score > 30 && // Must have played significantly in the sector
        !gameState.isInSecretLevel) { // Don't award during secret level
      
      console.log('🎶 MUSIC TRACK CHANGED - Previous track completed:', this.lastTrackName);
      console.log('🎶 Starting new track:', currentTrackName);
      this.checkSectorCompletion();
      this.sectorCollisions = 0; // Reset for new sector
    }
    
    // Update track name for next check
    this.lastTrackName = currentTrackName;
    
    this.player.update(deltaTime);
    this.particles.update(deltaTime);
    this.obstacles.update(deltaTime, difficultyLevel, gameState.score);

    // Check collisions
    const playerBounds = {
      x: this.player.x,
      y: this.player.y,
      width: this.player.width,
      height: this.player.height
    };

    if (this.collision.checkObstacleCollisions(playerBounds, this.obstacles.getObstacles())) {
      this.handleCollision();
    }
  }

  private handleCollision() {
    const gameState = useGameState.getState();
    const audioState = useAudio.getState();
    
    // If in secret level, track the collision but don't exit immediately
    if (gameState.isInSecretLevel) {
      console.log('💥 Collision in secret level!');
    }
    
    this.sectorCollisions++; // Track collision for this sector
    gameState.recordCollision(); // Track collision for crystal system
    
    console.log('Collision! Sector now has', this.sectorCollisions, 'collisions');
    
    // If in secret level and collision happened, exit the secret level
    if (gameState.isInSecretLevel) {
      console.log('Collision in secret level - exiting secret level');
      gameState.exitSecretLevel();
      this.background.setSecretLevel(false);
      this.obstacles.setSecretLevel(false);
      
      // Stop secret level music and resume normal
      if ((this as any).secretLevelTrack) {
        (this as any).secretLevelTrack.pause();
        (this as any).secretLevelTrack = null;
      }
      audioState.nextTrack();
    }
    
    // Play hit sound
    audioState.playHit();
    
    // Add collision particles
    this.particles.addCollisionParticles(this.player.x, this.player.y);
    
    // Update game state
    gameState.resetScore();
    this.background.changeTheme();
    
    // Reset difficulty progression when score resets to 0
    this.difficultyTimer = 0;
    
    // Reset game but keep playing
    this.resetGame();
  }

  private render() {
    // Clear canvas with cached dimensions
    this.ctx.clearRect(0, 0, this.gameWidth, this.gameHeight);
    
    // Always render game objects (even when not playing for visual feedback)
    this.background.render(this.ctx);
    this.obstacles.render(this.ctx);
    this.particles.render(this.ctx);
    
    // Render player differently during autopilot mode
    if (!this.isAutopilotMode) {
      this.player.render(this.ctx);
    }
    
    // Render orbiting crystals during epic ending
    if (this.isAutopilotMode) {
      this.renderOrbitingCrystals();
      this.renderAutopilotPlayer(); // Special rendering for player during autopilot
    } else if (this.isAutopilotMode === false) {
      // Normal player rendering when not in autopilot
      this.player.render(this.ctx);
    }
    
    // Render THE END screen if sequence is complete
    const elapsed = Date.now() - this.autopilotStartTime;
    if (!this.isAutopilotMode && elapsed < 12000 && this.orbitingCrystals.length > 0) {
      this.renderEndScreen();
    }
    
    // Game rendering complete
  }





  private gameLoop = (currentTime: number) => {
    if (!this.isRunning) return;

    const deltaTime = currentTime - this.lastTime;
    this.lastTime = currentTime;

    this.handleInput(deltaTime);
    this.updateGame(deltaTime);
    this.render();

    requestAnimationFrame(this.gameLoop);
  };

  public start() {
    if (this.isRunning) return;
    
    // Initialize game state
    
    this.isRunning = true;
    this.lastTime = performance.now();
    console.log('Game engine started');
    requestAnimationFrame(this.gameLoop);
  }

  public stop() {
    this.isRunning = false;
    this.removeEventListeners();
    console.log('Game engine stopped');
  }

  public destroy() {
    this.stop();
    this.removeEventListeners();
    // Clear any remaining timeouts/intervals
    this.obstacles.reset();
    console.log('Game engine destroyed');
  }

  public setTouchMovement(x: number, y: number) {
    // Block touch input if in landscape mode
    if (this.isLandscapeBlocked) {
      this.touchMovement = { x: 0, y: 0 };
      return;
    }
    this.touchMovement = { x, y };
  }
  
  public isOrientationBlocked(): boolean {
    return this.isLandscapeBlocked;
  }
  
  private triggerSecretLevel() {
    const gameState = useGameState.getState();
    const audioState = useAudio.getState();
    
    gameState.enterSecretLevel();
    
    // Switch to Starfield Symphony Remastered
    const secretTrack = new Audio('/audio/starfield_symphony_remastered.mp3');
    secretTrack.volume = audioState.isMuted ? 0 : 0.4;
    secretTrack.preload = 'auto';
    
    // Perfect cinematic timing - trigger epic ending before track ends
    secretTrack.addEventListener('timeupdate', () => {
      if (secretTrack.duration && !this.epicEndingTriggered) {
        const ANIMATION_DURATION = 8; // Epic ending takes exactly 8 seconds
        const triggerTime = secretTrack.duration - ANIMATION_DURATION;
        
        
        if (secretTrack.currentTime >= triggerTime && this.sectorCollisions === 0 && gameState.isInSecretLevel) {
          console.log('🎬 CINEMATIC TRIGGER - Starting epic ending with music!');
          console.log(`🎵 Triggering at ${secretTrack.currentTime.toFixed(1)}s of ${secretTrack.duration.toFixed(1)}s`);
          console.log(`🎯 ${ANIMATION_DURATION} seconds remaining in track`);
          
          this.epicEndingTriggered = true;
          this.secretLevelCompleted = true;
          this.startAutopilotMode();
        }
      }
    });

    // Fallback: Handle track ending for collision cases
    secretTrack.addEventListener('ended', () => {
      console.log('Secret level track ended');
      
      if (!this.epicEndingTriggered) {
        console.log('🎯 Final collision count for secret level:', this.sectorCollisions);
        console.log(`❌ Secret level completed with ${this.sectorCollisions} collisions, exiting normally`);
        gameState.exitSecretLevel();
        this.background.setSecretLevel(false);
        this.obstacles.setSecretLevel(false);
        audioState.nextTrack();
      } else {
        console.log('🎬 Track ended perfectly - epic ending already triggered via cinematic timing!');
      }
    });
    
    // Store reference to secret track for cleanup
    (this as any).secretLevelTrack = secretTrack;
    
    // Stop current track and start secret track
    if (audioState.currentTrack) {
      audioState.currentTrack.pause();
      audioState.currentTrack.currentTime = 0;
    }
    
    // Play secret track if not muted
    if (!audioState.isMuted) {
      secretTrack.play().catch(error => {
        console.log('Secret level track play prevented:', error);
      });
    }
    
    // Set special background and obstacles for secret level
    this.background.setSecretLevel(true);
    this.obstacles.setSecretLevel(true);
    
    console.log('🎆 SECRET LEVEL ACTIVATED: Starfield Symphony - Nebula Collapse!');
    
    // IMPORTANT: Reset collision tracking for secret level
    this.sectorCollisions = 0;
    this.secretLevelCompleted = false;
    this.epicEndingTriggered = false; // Reset epic ending trigger
    this.secretLevelTriggered = false; // Allow re-triggering for retries
    
    console.log('🔄 Secret level collision counter reset to:', this.sectorCollisions);
    console.log('🔄 Epic ending trigger reset for new attempt');
  }
  
  // Epic ending autopilot mode methods
  private startAutopilotMode() {
    this.isAutopilotMode = true;
    this.autopilotStartTime = Date.now();
    
    // Initialize orbiting crystals with progressive colors
    const crystalColors = [
      { name: 'Blue', color: '#00ffff', glow: 'rgba(0, 255, 255, 0.8)' },
      { name: 'Yellow', color: '#ffff00', glow: 'rgba(255, 255, 0, 0.8)' },
      { name: 'Purple', color: '#aa00ff', glow: 'rgba(170, 0, 255, 0.8)' },
      { name: 'Orange', color: '#ff8800', glow: 'rgba(255, 136, 0, 0.8)' },
      { name: 'Pink', color: '#ff00aa', glow: 'rgba(255, 0, 170, 0.8)' },
      { name: 'Red', color: '#ff0044', glow: 'rgba(255, 0, 68, 0.8)' },
      { name: 'Green', color: '#00ff44', glow: 'rgba(0, 255, 68, 0.8)' }
    ];
    
    this.orbitingCrystals = crystalColors.map((crystal, index) => ({
      angle: (index * Math.PI * 2) / 7, // Evenly distribute around circle
      radius: 60 + index * 8, // Slightly different radii for visual appeal
      color: crystal.color,
      glow: crystal.glow,
      name: crystal.name
    }));
    
    console.log('🎆 Epic ending autopilot mode activated!');
  }
  
  private updateAutopilotMode(deltaTime: number) {
    const elapsed = Date.now() - this.autopilotStartTime;
    const duration = 8000; // 8 second duration
    const progress = Math.min(elapsed / duration, 1);
    
    console.log(`Autopilot progress: ${(progress * 100).toFixed(1)}% (${elapsed}ms/${duration}ms)`);
    
    // Pre-calculate frequently used values for performance
    const centerX = this.gameWidth / 2;
    const centerY = this.gameHeight / 2;
    const targetX = centerX - this.player.width / 2;
    const targetY = centerY - this.player.height / 2;
    const deltaTimeSeconds = deltaTime * 0.001;
    
    // Handle the dramatic warp effect in final moments
    if (progress >= 0.95) {
      // Final warp phase - everything rushes toward center at light speed
      const warpProgress = (progress - 0.95) / 0.05; // 0 to 1 over last 5%
      
      if (warpProgress >= 0.8) {
        // Light speed warp - everything zooms to center
        const warpSpeed = deltaTime * 0.1 * (1 + warpProgress * 10); // Accelerating speed
        this.player.x += (centerX - this.player.x) * warpSpeed;
        this.player.y += (centerY - this.player.y) * warpSpeed;
        
        // Crystals also warp to center - optimized batch update
        const radiusDecrement = deltaTime * 0.5;
        for (let i = 0; i < this.orbitingCrystals.length; i++) {
          this.orbitingCrystals[i].radius = Math.max(0, this.orbitingCrystals[i].radius - radiusDecrement);
        }
      } else {
        // Normal centering with radiant white glow building up
        const centeringSpeed = deltaTime * 0.008;
        this.player.x += (targetX - this.player.x) * centeringSpeed;
        this.player.y += (targetY - this.player.y) * centeringSpeed;
        
        // Update crystal orbits - optimized batch calculation
        const orbitSpeed = deltaTime * 0.003;
        const radiusIncrement = deltaTime * 0.02;
        for (let i = 0; i < this.orbitingCrystals.length; i++) {
          this.orbitingCrystals[i].angle += orbitSpeed;
          this.orbitingCrystals[i].radius = Math.min(120, this.orbitingCrystals[i].radius + radiusIncrement);
        }
      }
    } else {
      // Normal autopilot behavior - optimized calculations
      const centeringSpeed = deltaTime * 0.008;
      this.player.x += (targetX - this.player.x) * centeringSpeed;
      this.player.y += (targetY - this.player.y) * centeringSpeed;
      
      // Update crystal orbits - pre-calculated values for all crystals
      const orbitSpeed = deltaTime * 0.003;
      const radiusIncrement = deltaTime * 0.02;
      for (let i = 0; i < this.orbitingCrystals.length; i++) {
        this.orbitingCrystals[i].angle += orbitSpeed;
        this.orbitingCrystals[i].radius = Math.min(120, this.orbitingCrystals[i].radius + radiusIncrement);
      }
    }
    
    // Update player animation
    this.player.update(deltaTime, false);
    
    // Update particles for dramatic effect
    this.particles.update(deltaTime);
    
    // Trigger ending when sequence completes
    if (progress >= 1) {
      console.log('Epic ending sequence complete, showing THE END');
      this.triggerGameEndScreen();
    }
  }
  
  private renderOrbitingCrystals() {
    const centerX = this.player.x + this.player.width / 2;
    const centerY = this.player.y + this.player.height / 2;
    const elapsed = Date.now() - this.autopilotStartTime;
    const progress = Math.min(elapsed / 8000, 1);
    
    // Pre-calculate glow phase values once for all crystals
    const glowPhase = progress >= 0.95;
    const glowIntensity = glowPhase ? Math.min((progress - 0.95) / 0.05, 1) : 0;
    const shadowBlur = glowPhase ? 30 * glowIntensity : 15;
    const glowSize = glowPhase ? 12 + glowIntensity * 8 : 0;
    const alpha = glowPhase ? 0.8 + glowIntensity * 0.2 : 1;
    
    this.ctx.save();
    
    // Optimized rendering loop with pre-calculated trigonometry
    for (let i = 0; i < this.orbitingCrystals.length; i++) {
      const crystal = this.orbitingCrystals[i];
      const x = centerX + Math.cos(crystal.angle) * crystal.radius;
      const y = centerY + Math.sin(crystal.angle) * crystal.radius;
      
      if (glowPhase) {
        // Radiant white glow effect - optimized rendering
        this.ctx.shadowColor = '#ffffff';
        this.ctx.shadowBlur = shadowBlur;
        this.ctx.fillStyle = `rgba(255, 255, 255, ${alpha})`;
        
        // Larger crystal size during glow
        this.ctx.beginPath();
        this.ctx.arc(x, y, glowSize, 0, Math.PI * 2);
        this.ctx.fill();
        
        // Additional bright white core
        this.ctx.fillStyle = '#ffffff';
        this.ctx.beginPath();
        this.ctx.arc(x, y, 6, 0, Math.PI * 2);
        this.ctx.fill();
        
      } else {
        // Normal crystal rendering - optimized path drawing
        this.ctx.globalAlpha = 1;
        this.ctx.fillStyle = crystal.color;
        this.ctx.strokeStyle = crystal.color;
        this.ctx.lineWidth = 3;
        this.ctx.shadowColor = crystal.color;
        this.ctx.shadowBlur = 15;
        
        // Draw diamond shape in single path
        this.ctx.beginPath();
        this.ctx.moveTo(x, y - 10);
        this.ctx.lineTo(x + 7, y);
        this.ctx.lineTo(x, y + 10);
        this.ctx.lineTo(x - 7, y);
        this.ctx.closePath();
        this.ctx.fill();
        this.ctx.stroke();
      }
    }
    
    // Reset shadow once at the end
    this.ctx.shadowBlur = 0;
    this.ctx.restore();
  }
  
  private renderAutopilotPlayer() {
    const elapsed = Date.now() - this.autopilotStartTime;
    const progress = Math.min(elapsed / 8000, 1);
    const glowPhase = progress >= 0.95;
    const glowIntensity = glowPhase ? Math.min((progress - 0.95) / 0.05, 1) : 0;
    
    this.ctx.save();
    
    if (glowPhase) {
      // Radiant white glow effect for Beatfox
      this.ctx.shadowColor = '#ffffff';
      this.ctx.shadowBlur = 40 * glowIntensity;
      
      // Render with white glow overlay
      this.ctx.globalCompositeOperation = 'source-over';
      this.player.render(this.ctx);
      
      // Add radiant white overlay
      this.ctx.globalCompositeOperation = 'screen';
      this.ctx.fillStyle = `rgba(255, 255, 255, ${0.6 * glowIntensity})`;
      this.ctx.fillRect(this.player.x, this.player.y, this.player.width, this.player.height);
      
      this.ctx.globalCompositeOperation = 'source-over';
    } else {
      // Normal player rendering
      this.player.render(this.ctx);
    }
    
    this.ctx.restore();
  }
  
  private triggerGameEndScreen() {
    console.log('🎬 THE END screen triggered');
    this.isAutopilotMode = false;
    const gameState = useGameState.getState();
    
    // Show THE END for 4 seconds then return to normal game
    setTimeout(() => {
      console.log('Epic ending sequence complete, returning to normal game');
      gameState.exitSecretLevel();
      this.background.setSecretLevel(false);
      this.obstacles.setSecretLevel(false);
      this.orbitingCrystals = []; // Clear crystals
      const audioState = useAudio.getState();
      audioState.nextTrack();
    }, 4000);
  }
  
  private renderEndScreen() {
    // Create THE END overlay
    this.ctx.save();
    this.ctx.fillStyle = 'rgba(0, 0, 0, 0.9)';
    this.ctx.fillRect(0, 0, this.gameWidth, this.gameHeight);
    
    // Add subtle glow effect
    this.ctx.shadowColor = '#ffffff';
    this.ctx.shadowBlur = 20;
    
    this.ctx.fillStyle = '#ffffff';
    this.ctx.font = 'bold 48px Arial';
    this.ctx.textAlign = 'center';
    this.ctx.fillText('THE END', this.gameWidth / 2, this.gameHeight / 2);
    
    this.ctx.shadowBlur = 0;
    this.ctx.fillStyle = '#aaaaaa';
    this.ctx.font = '18px Arial';
    this.ctx.fillText('Thank you for playing Beatfox Drift!', this.gameWidth / 2, this.gameHeight / 2 + 60);
    
    this.ctx.restore();
  }
  
  // Public method for test button
  public triggerEpicEnding() {
    console.log('🧪 Testing epic ending sequence');
    const gameState = useGameState.getState();
    
    // Force game into playing state for autopilot
    if (!gameState.isPlaying) {
      gameState.start();
    }
    
    // Force into secret level for testing
    if (!gameState.isInSecretLevel) {
      gameState.enterSecretLevel();
      this.background.setSecretLevel(true);
      this.obstacles.setSecretLevel(true);
    }
    
    this.sectorCollisions = 0; // Simulate perfect completion
    this.secretLevelCompleted = true;
    this.startAutopilotMode();
    
    console.log('🎆 Epic ending test started');
  }
}
