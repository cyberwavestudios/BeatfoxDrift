import { create } from "zustand";

// Soundtrack tracks with corresponding space sectors
export const SOUNDTRACK_TRACKS = [
  { file: '/audio/Against All Odds.mp3', sector: 'Resistance Nebula', color: '#ff4444' },
  { file: '/audio/Chem T Haze.mp3', sector: 'Toxic Clouds', color: '#44ff44' },
  { file: '/audio/Clouded.mp3', sector: 'Misty Void', color: '#888888' },
  { file: '/audio/Cosmic Nostalgia.mp3', sector: 'Memory Fields', color: '#ff88ff' },
  { file: '/audio/Cyberbucks.mp3', sector: 'Digital Economy', color: '#00ffff' },
  { file: '/audio/Invasion.mp3', sector: 'War Zone', color: '#ff6600' },
  { file: '/audio/Kyber 1.mp3', sector: 'Crystal Depths', color: '#4444ff' },
  { file: '/audio/Memento Stellarum.mp3', sector: 'Star Memorial', color: '#ffff88' },
  { file: '/audio/Paradise Rift.mp3', sector: 'Paradise Lost', color: '#88ffaa' },
  { file: '/audio/Phases.mp3', sector: 'Phase Shifter', color: '#aa88ff' },
  { file: '/audio/Synchronicity.mp3', sector: 'Sync Matrix', color: '#ffaa88' },
  { file: '/audio/Termina.mp3', sector: 'Terminal Station', color: '#ff8888' },
  { file: '/audio/Under Pressure.mp3', sector: 'Pressure Zone', color: '#8888ff' }
];

// Special bonus track
export const SECRET_TRACK = {
  file: '/audio/starfield_symphony_remastered.mp3',
  sector: 'Starfield Symphony (Remastered)',
  color: '#000000'
};

interface AudioState {
  // Soundtrack system
  currentTrackIndex: number;
  currentTrack: HTMLAudioElement | null;
  shuffledPlaylist: number[];
  isPlaylistInitialized: boolean;
  secretLevelUnlocked: boolean;
  
  // Sound effects
  hitSound: HTMLAudioElement | null;
  successSound: HTMLAudioElement | null;
  isMuted: boolean;
  
  // Setter functions
  initializeSoundtrack: () => void;
  setHitSound: (sound: HTMLAudioElement) => void;
  setSuccessSound: (sound: HTMLAudioElement) => void;
  unlockSecretLevel: () => void;
  
  // Control functions
  toggleMute: () => void;
  playHit: () => void;
  playSuccess: () => void;
  getCurrentSector: () => { name: string; color: string };
  nextTrack: () => void;
  getMusicBeat: () => number;
}

// Shuffle function
const shuffleArray = (array: number[]): number[] => {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
};

export const useAudio = create<AudioState>((set, get) => ({
  // Soundtrack system
  currentTrackIndex: 0,
  currentTrack: null,
  shuffledPlaylist: [],
  isPlaylistInitialized: false,
  secretLevelUnlocked: false,
  
  // Sound effects
  hitSound: null,
  successSound: null,
  isMuted: true, // Start muted by default
  
  initializeSoundtrack: () => {
    const { isPlaylistInitialized, isMuted } = get();
    if (isPlaylistInitialized) return;
    
    // Create shuffled playlist
    const playlist = Array.from({ length: SOUNDTRACK_TRACKS.length }, (_, i) => i);
    const shuffledPlaylist = shuffleArray(playlist);
    
    // Load first track with preloading
    const firstTrackIndex = shuffledPlaylist[0];
    const track = new Audio(SOUNDTRACK_TRACKS[firstTrackIndex].file);
    track.volume = isMuted ? 0 : 0.4;
    track.preload = 'auto'; // Preload for instant playback
    
    // Handle track ending - move to next track
    track.addEventListener('ended', () => {
      get().nextTrack();
    });
    
    set({ 
      shuffledPlaylist,
      currentTrackIndex: 0,
      currentTrack: track,
      isPlaylistInitialized: true
    });
    
    // Start playing if not muted
    if (!isMuted) {
      track.play().catch(error => {
        console.log("Soundtrack autoplay prevented:", error);
      });
    }
    
    console.log(`Soundtrack initialized with ${SOUNDTRACK_TRACKS.length} tracks in shuffle mode`);
    console.log(`Starting with: ${SOUNDTRACK_TRACKS[firstTrackIndex].sector}`);
  },
  
  nextTrack: () => {
    const { shuffledPlaylist, currentTrackIndex, isMuted } = get();
    
    // Move to next track in shuffled playlist
    const nextIndex = (currentTrackIndex + 1) % shuffledPlaylist.length;
    const trackIndex = shuffledPlaylist[nextIndex];
    
    // Create new track with preloading for seamless transitions
    const track = new Audio(SOUNDTRACK_TRACKS[trackIndex].file);
    track.volume = isMuted ? 0 : 0.4;
    track.preload = 'auto'; // Preload track for faster startup
    
    // Handle track ending
    track.addEventListener('ended', () => {
      get().nextTrack();
    });
    
    // Stop current track if playing
    const { currentTrack } = get();
    if (currentTrack) {
      currentTrack.pause();
      currentTrack.currentTime = 0;
    }
    
    set({
      currentTrackIndex: nextIndex,
      currentTrack: track
    });
    
    // Start new track if not muted
    if (!isMuted) {
      track.play().catch(error => {
        console.log("Track change play prevented:", error);
      });
    }
    
    console.log(`Sector changed to: ${SOUNDTRACK_TRACKS[trackIndex].sector}`);
  },
  
  getCurrentSector: () => {
    const { shuffledPlaylist, currentTrackIndex } = get();
    if (shuffledPlaylist.length === 0) {
      return { name: 'Deep Space', color: '#00aaff' };
    }
    
    const trackIndex = shuffledPlaylist[currentTrackIndex];
    const track = SOUNDTRACK_TRACKS[trackIndex];
    return { name: track.sector, color: track.color };
  },
  
  setHitSound: (sound) => set({ hitSound: sound }),
  setSuccessSound: (sound) => set({ successSound: sound }),
  
  unlockSecretLevel: () => {
    set({ secretLevelUnlocked: true });
    console.log('Special track unlocked: Starfield Symphony (Remastered)!');
  },
  
  toggleMute: () => {
    const { isMuted, currentTrack } = get();
    const newMutedState = !isMuted;
    
    // Update track volume
    if (currentTrack) {
      currentTrack.volume = newMutedState ? 0 : 0.4;
      
      if (!newMutedState && currentTrack.paused) {
        currentTrack.play().catch(error => {
          console.log("Resume play prevented:", error);
        });
      }
    }
    
    set({ isMuted: newMutedState });
    console.log(`Sound ${newMutedState ? 'muted' : 'unmuted'}`);
  },
  
  playHit: () => {
    const { hitSound, isMuted } = get();
    if (hitSound && !isMuted) {
      const soundClone = hitSound.cloneNode() as HTMLAudioElement;
      soundClone.volume = 0.3;
      soundClone.play().catch(error => {
        console.log("Hit sound play prevented:", error);
      });
    } else if (isMuted) {
      console.log("Hit sound skipped (muted)");
    }
  },
  
  playSuccess: () => {
    const { successSound, isMuted } = get();
    if (successSound && !isMuted) {
      successSound.currentTime = 0;
      successSound.play().catch(error => {
        console.log("Success sound play prevented:", error);
      });
    } else if (isMuted) {
      console.log("Success sound skipped (muted)");
    }
  },

  getMusicBeat: () => {
    const { currentTrack } = get();
    if (!currentTrack || currentTrack.paused) return 0;
    
    // Create a beat pulse based on music timing - approximate 120 BPM
    const currentTime = currentTrack.currentTime;
    const beatFreq = 2; // 2 beats per second = 120 BPM
    return Math.sin(currentTime * beatFreq * Math.PI * 2);
  }
}));
