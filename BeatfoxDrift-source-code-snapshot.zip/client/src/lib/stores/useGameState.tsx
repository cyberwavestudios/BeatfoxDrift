import { create } from 'zustand';
import { subscribeWithSelector } from 'zustand/middleware';

export type GamePhase = 'ready' | 'playing' | 'paused';

interface GameState {
  score: number;
  highScore: number;
  isPlaying: boolean;
  gamePhase: GamePhase;
  
  // Cyber-crystal system
  cyberCrystals: number;
  currentSectorCollisions: number;
  totalSectorsCleared: number;
  isInSecretLevel: boolean;
  
  // Actions
  start: () => void;
  pause: () => void;
  resume: () => void;
  incrementScore: () => void;
  resetScore: () => void;
  setHighScore: (score: number) => void;
  
  // Crystal system actions
  recordCollision: () => void;
  completeSector: () => void;
  awardCyberCrystal: () => void;
  enterSecretLevel: () => void;
  exitSecretLevel: () => void;
}

export const useGameState = create<GameState>()(
  subscribeWithSelector((set, get) => ({
    score: 0,
    highScore: (() => {
      try {
        return parseInt(localStorage.getItem('beatfox-highscore') || '0');
      } catch (error) {
        console.warn('Failed to load high score from localStorage:', error);
        return 0;
      }
    })(),
    isPlaying: false,
    gamePhase: 'ready',
    
    // Cyber-crystal system - RESET to ensure clean state
    cyberCrystals: (() => {
      // Clear any existing crystal data to ensure fresh start
      try {
        localStorage.removeItem('beatfox-crystals');
      } catch (error) {
        console.warn('Failed to clear crystal data:', error);
      }
      return 0;
    })(),
    currentSectorCollisions: 0,
    totalSectorsCleared: 0,
    isInSecretLevel: false,
    
    start: () => {
      console.log('Game started');
      set({
        isPlaying: true,
        gamePhase: 'playing',
        score: 0,
        currentSectorCollisions: 0
      });
    },
    
    pause: () => {
      set({
        isPlaying: false,
        gamePhase: 'paused'
      });
    },
    
    resume: () => {
      set({
        isPlaying: true,
        gamePhase: 'playing'
      });
    },
    
    incrementScore: () => {
      const { score, highScore } = get();
      const newScore = score + 1;
      
      set({ score: newScore });
      
      // Check for milestone achievements
      const milestones = [500, 1000, 1500, 2000, 2500, 3000];
      if (milestones.includes(newScore)) {
        console.log(`🚀 Milestone reached: ${newScore} points! Entering new space sector!`);
      }
      
      if (newScore > highScore) {
        set({ highScore: newScore });
        try {
          localStorage.setItem('beatfox-highscore', newScore.toString());
          console.log('New high score:', newScore);
        } catch (error) {
          console.warn('Failed to save high score to localStorage:', error);
        }
      }
    },
    
    resetScore: () => {
      console.log('Score reset. Final score:', get().score);
      set({ score: 0 });
    },
    
    setHighScore: (score: number) => {
      set({ highScore: score });
      try {
        localStorage.setItem('beatfox-highscore', score.toString());
      } catch (error) {
        console.warn('Failed to save high score to localStorage:', error);
      }
    },
    
    // Crystal system actions
    recordCollision: () => {
      set(state => ({ currentSectorCollisions: state.currentSectorCollisions + 1 }));
    },
    
    completeSector: () => {
      const { currentSectorCollisions } = get();
      
      console.log('Completing sector with collision count:', currentSectorCollisions);
      
      set(state => ({ 
        totalSectorsCleared: state.totalSectorsCleared + 1,
        currentSectorCollisions: 0 // Reset for next sector
      }));
      
      // Award crystal if sector was completed perfectly
      if (currentSectorCollisions === 0) {
        console.log('Awarding crystal for perfect sector!');
        get().awardCyberCrystal();
      } else {
        console.log('No crystal awarded - had', currentSectorCollisions, 'collisions');
      }
    },
    
    awardCyberCrystal: () => {
      const { cyberCrystals } = get();
      
      // Don't award if already at maximum
      if (cyberCrystals >= 7) {
        console.log('Already at maximum crystal count (7/7)');
        return;
      }
      
      const newCrystalCount = cyberCrystals + 1;
      
      set({ cyberCrystals: newCrystalCount });
      
      try {
        localStorage.setItem('beatfox-crystals', newCrystalCount.toString());
      } catch (error) {
        console.warn('Failed to save cyber crystals to localStorage:', error);
      }
      
      console.log(`💎 Cyber-Crystal awarded! Total: ${newCrystalCount}/7`);
      
      // Check if secret level should be unlocked
      if (newCrystalCount === 7) {
        console.log('🎉 All 7 Cyber-Crystals collected! Secret level unlocked!');
        // Secret level will be triggered externally
      }
    },
    
    
    enterSecretLevel: () => {
      set({ isInSecretLevel: true });
      console.log('🌟 Entering secret bonus level: Termina Metal!');
    },
    
    exitSecretLevel: () => {
      set({ isInSecretLevel: false });
      console.log('Exiting secret level');
    }
  }))
);
