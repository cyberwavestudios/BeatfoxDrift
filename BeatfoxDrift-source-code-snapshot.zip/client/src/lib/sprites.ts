export class BeatfoxSprite {
  public x: number;
  public y: number;
  public width: number = 48;
  public height: number = 32;
  
  private animationTime: number = 0;
  private hoverOffset: number = 0;
  private glowIntensity: number = 0;
  private hoverboardParticles: { x: number; y: number; life: number; vx: number; vy: number; active: boolean }[] = [];
  private particlePool: { x: number; y: number; life: number; vx: number; vy: number; active: boolean }[] = [];
  private activeParticleCount: number = 0;
  
  // Pre-calculated constants
  private readonly ONE_THOUSANDTH = 0.001;
  private readonly HOVER_SPEED = 0.003;
  private readonly GLOW_INCREASE = 0.01;
  private readonly GLOW_DECREASE = 0.005;

  constructor(x: number, y: number) {
    this.x = x;
    this.y = y;
  }

  private getParticleFromPool() {
    if (this.particlePool.length > 0) {
      return this.particlePool.pop()!;
    }
    return { x: 0, y: 0, life: 0, vx: 0, vy: 0, active: false };
  }
  
  private returnParticleToPool(particle: { x: number; y: number; life: number; vx: number; vy: number; active: boolean }) {
    if (this.particlePool.length < 50) { // Cap pool size
      particle.active = false;
      this.particlePool.push(particle);
    }
  }
  
  update(deltaTime: number, isDashing: boolean = false) {
    this.animationTime += deltaTime;
    
    // Floating animation
    this.hoverOffset = Math.sin(this.animationTime * this.HOVER_SPEED) * 3;
    
    // Glow effect during dash
    if (isDashing) {
      this.glowIntensity = Math.min(1, this.glowIntensity + deltaTime * this.GLOW_INCREASE);
    } else {
      this.glowIntensity = Math.max(0, this.glowIntensity - deltaTime * this.GLOW_DECREASE);
    }

    // Update hoverboard particle trail with efficient array management
    const dt = deltaTime * this.ONE_THOUSANDTH;
    let writeIndex = 0;
    
    for (let i = 0; i < this.activeParticleCount; i++) {
      const particle = this.hoverboardParticles[i];
      if (!particle.active) continue;
      
      particle.x += particle.vx * dt;
      particle.y += particle.vy * dt;
      particle.life -= deltaTime;

      if (particle.life <= 0) {
        this.returnParticleToPool(particle);
      } else {
        this.hoverboardParticles[writeIndex++] = particle;
      }
    }
    
    this.activeParticleCount = writeIndex;

    // Spawn new rocket particles from the rocket thruster specifically
    if (Math.random() < 0.8) {
      const particleCount = 2 + Math.floor(Math.random() * 3);
      for (let i = 0; i < particleCount && this.activeParticleCount < this.hoverboardParticles.length; i++) {
        const particle = this.getParticleFromPool();
        particle.x = this.x - 2 + Math.random() * 3; // From the rocket thruster position
        particle.y = this.y + this.height + 1 + Math.random() * 2;
        particle.life = 350 + Math.random() * 200; // 0.35-0.55 seconds
        particle.vx = -70 - Math.random() * 40; // Moving backward
        particle.vy = (Math.random() - 0.5) * 25; // Some vertical spread
        particle.active = true;
        
        this.hoverboardParticles[this.activeParticleCount++] = particle;
      }
    }
  }

  render(ctx: CanvasRenderingContext2D) {
    const renderY = this.y + this.hoverOffset;
    
    // Render hoverboard particle trail first (behind sprite) - optimized
    for (let i = 0; i < this.activeParticleCount; i++) {
      const particle = this.hoverboardParticles[i];
      if (!particle.active) continue;
      
      const alpha = Math.max(0, particle.life / 400);
      const size = 1.5 + (1 - alpha) * 1.5; // Particles grow as they fade
      const halfSize = size * 0.5;
      
      // Blue rocket exhaust particles
      ctx.fillStyle = `rgba(100, 180, 255, ${alpha})`;
      ctx.fillRect(particle.x - halfSize, particle.y - halfSize, size, size);
      
      // Inner bright core (only for high alpha particles)
      if (alpha > 0.6) {
        ctx.fillStyle = `rgba(200, 230, 255, ${(alpha - 0.6) * 2.5})`;
        ctx.fillRect(particle.x - 0.5, particle.y - 0.5, 1, 1);
      }
    }
    
    // Glow effect during dash
    if (this.glowIntensity > 0) {
      ctx.save();
      ctx.shadowColor = '#00ffff';
      ctx.shadowBlur = 20 * this.glowIntensity;
    }
    
    // === FUTURISTIC HOVERBOARD (extended design) ===
    const boardY = renderY + this.height - 2;
    
    // Extended main hoverboard platform - longer so Beatfox isn't too close to rocket
    ctx.fillStyle = '#b0b0b0';
    ctx.fillRect(this.x + 4, boardY, 42, 5); // Extended by 6 units
    
    // Board highlights and edges
    ctx.fillStyle = '#e0e0e0';
    ctx.fillRect(this.x + 4, boardY, 42, 1); // Top highlight
    ctx.fillStyle = '#808080';
    ctx.fillRect(this.x + 4, boardY + 4, 42, 1); // Bottom shadow
    
    // Rocket thruster at the very back - enhanced
    ctx.fillStyle = '#333333';
    ctx.fillRect(this.x - 2, boardY + 1, 8, 3); // Moved further back
    
    // Thruster glow effect - pulsing blue from rocket position
    const thrusterGlow = 0.6 + Math.sin(this.animationTime * 0.008) * 0.4;
    ctx.fillStyle = `rgba(100, 180, 255, ${thrusterGlow})`;
    ctx.fillRect(this.x - 4, boardY + 1.5, 5, 2); // From rocket position
    
    // Thruster core - bright center
    ctx.fillStyle = `rgba(200, 230, 255, ${thrusterGlow * 0.8})`;
    ctx.fillRect(this.x - 3, boardY + 2, 3, 1);
    
    // Hover repulsors underneath - blue glow
    const repulsorGlow = 0.4 + Math.sin(this.animationTime * 0.005) * 0.3;
    ctx.fillStyle = `rgba(100, 200, 255, ${repulsorGlow})`;
    ctx.fillRect(this.x + 10, boardY + 5, 4, 1);
    ctx.fillRect(this.x + 22, boardY + 5, 4, 1);
    ctx.fillRect(this.x + 34, boardY + 5, 4, 1);
    
    // Board surface details - tech lines
    ctx.fillStyle = '#999999';
    ctx.fillRect(this.x + 8, boardY + 2, 1, 1);
    ctx.fillRect(this.x + 16, boardY + 2, 1, 1);
    ctx.fillRect(this.x + 24, boardY + 2, 1, 1);
    ctx.fillRect(this.x + 32, boardY + 2, 1, 1);
    ctx.fillRect(this.x + 40, boardY + 2, 1, 1);
    
    // Extended board edge glow
    ctx.fillStyle = `rgba(100, 200, 255, ${0.3 + repulsorGlow * 0.3})`;
    ctx.fillRect(this.x + 3, boardY + 5, 44, 1);
    
    // === FOX CHARACTER (looking toward mission ahead) ===
    
    // Tail (large, fluffy, orange with white tip)
    ctx.fillStyle = '#ff6600'; // Base orange
    ctx.fillRect(this.x + 3, renderY + 12, 8, 16);
    ctx.fillRect(this.x + 1, renderY + 14, 4, 12);
    
    // Tail highlights
    ctx.fillStyle = '#ff9933';
    ctx.fillRect(this.x + 4, renderY + 13, 6, 4);
    ctx.fillRect(this.x + 2, renderY + 15, 3, 4);
    
    // Tail white tip
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(this.x + 4, renderY + 18, 6, 10);
    ctx.fillRect(this.x + 2, renderY + 20, 3, 6);
    
    // Tail white tip shading
    ctx.fillStyle = '#f0f0f0';
    ctx.fillRect(this.x + 5, renderY + 24, 4, 4);
    
    // Body (teal suit/shirt)
    ctx.fillStyle = '#1a7373';
    ctx.fillRect(this.x + 12, renderY + 18, 20, 14);
    
    // Body highlights
    ctx.fillStyle = '#269999';
    ctx.fillRect(this.x + 13, renderY + 19, 18, 4);
    
    // Body shadows
    ctx.fillStyle = '#0d4d4d';
    ctx.fillRect(this.x + 14, renderY + 28, 16, 4);
    
    // Chest emblem/logo (circular teal design)
    ctx.fillStyle = '#33cccc';
    ctx.fillRect(this.x + 18, renderY + 22, 8, 6);
    ctx.fillStyle = '#1a7373';
    ctx.fillRect(this.x + 19, renderY + 23, 6, 4);
    ctx.fillStyle = '#0d4d4d';
    ctx.fillRect(this.x + 20, renderY + 24, 4, 2);
    
    // Arms (orange fur)
    ctx.fillStyle = '#ff6600';
    ctx.fillRect(this.x + 8, renderY + 20, 6, 10);
    ctx.fillRect(this.x + 30, renderY + 20, 6, 10);
    
    // Arm highlights
    ctx.fillStyle = '#ff9933';
    ctx.fillRect(this.x + 9, renderY + 21, 4, 3);
    ctx.fillRect(this.x + 31, renderY + 21, 4, 3);
    
    // Hands/paws (cream colored)
    ctx.fillStyle = '#ffcc99';
    ctx.fillRect(this.x + 8, renderY + 28, 6, 4);
    ctx.fillRect(this.x + 30, renderY + 28, 6, 4);
    
    // Legs (sitting position, orange)
    ctx.fillStyle = '#ff6600';
    ctx.fillRect(this.x + 14, renderY + 30, 6, 8);
    ctx.fillRect(this.x + 24, renderY + 30, 6, 8);
    
    // Leg highlights
    ctx.fillStyle = '#ff9933';
    ctx.fillRect(this.x + 15, renderY + 31, 4, 3);
    ctx.fillRect(this.x + 25, renderY + 31, 4, 3);
    
    // Head (large, orange) - Enhanced with more definition
    ctx.fillStyle = '#ff6600';
    ctx.fillRect(this.x + 12, renderY + 4, 20, 16);
    
    // Head highlights - enhanced for more dimension
    ctx.fillStyle = '#ff9933';
    ctx.fillRect(this.x + 14, renderY + 6, 16, 6);
    ctx.fillStyle = '#ffaa44'; // Additional bright highlights
    ctx.fillRect(this.x + 14, renderY + 6, 16, 2);
    ctx.fillRect(this.x + 12, renderY + 8, 2, 8);
    
    // Head shadows - enhanced depth
    ctx.fillStyle = '#cc4400';
    ctx.fillRect(this.x + 14, renderY + 16, 16, 4);
    ctx.fillStyle = '#aa3300'; // Deeper shadows
    ctx.fillRect(this.x + 28, renderY + 8, 4, 8);
    
    // Ears (pointed, orange)
    ctx.fillStyle = '#ff6600';
    ctx.fillRect(this.x + 10, renderY + 2, 6, 10);
    ctx.fillRect(this.x + 28, renderY + 2, 6, 10);
    
    // Ear highlights
    ctx.fillStyle = '#ff9933';
    ctx.fillRect(this.x + 11, renderY + 3, 4, 4);
    ctx.fillRect(this.x + 29, renderY + 3, 4, 4);
    
    // Ear inner (pink)
    ctx.fillStyle = '#ff99cc';
    ctx.fillRect(this.x + 12, renderY + 4, 2, 4);
    ctx.fillRect(this.x + 30, renderY + 4, 2, 4);
    
    // Muzzle (cream/white)
    ctx.fillStyle = '#ffcc99';
    ctx.fillRect(this.x + 18, renderY + 12, 8, 8);
    
    // Muzzle highlight
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(this.x + 19, renderY + 13, 6, 3);
    
    // Nose (black)
    ctx.fillStyle = '#000000';
    ctx.fillRect(this.x + 21, renderY + 16, 2, 2);
    
    // === ENHANCED CYBER EYES (both visible now) ===
    // Left eye - enhanced with cyber blue iris
    ctx.fillStyle = '#000000';
    ctx.fillRect(this.x + 16, renderY + 10, 4, 4); // Larger
    
    // Left iris - cyber blue
    ctx.fillStyle = '#0088ff';
    ctx.fillRect(this.x + 17, renderY + 11, 2, 2);
    
    // Left eye glow highlight - cyan
    ctx.fillStyle = '#00ffff';
    ctx.fillRect(this.x + 17, renderY + 11, 1, 1);
    
    // Left bright spot
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(this.x + 18, renderY + 12, 1, 1);
    
    // Right eye - enhanced with cyber blue iris
    ctx.fillStyle = '#000000';
    ctx.fillRect(this.x + 24, renderY + 10, 4, 4); // Larger
    
    // Right iris - cyber blue
    ctx.fillStyle = '#0088ff';
    ctx.fillRect(this.x + 25, renderY + 11, 2, 2);
    
    // Right eye glow highlight - cyan
    ctx.fillStyle = '#00ffff';
    ctx.fillRect(this.x + 25, renderY + 11, 1, 1);
    
    // Right bright spot
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(this.x + 26, renderY + 12, 1, 1);
    
    // === STUDIO HEADPHONES (redesigned for clarity) ===
    // Main headphone band (padded, professional style)
    ctx.fillStyle = '#2a2a2a';
    ctx.fillRect(this.x + 14, renderY + 1, 16, 4);
    
    // Headphone band padding (inner cushion)
    ctx.fillStyle = '#1a1a1a';
    ctx.fillRect(this.x + 15, renderY + 2, 14, 2);
    
    // Headphone band metallic highlights
    ctx.fillStyle = '#666666';
    ctx.fillRect(this.x + 14, renderY + 1, 16, 1);
    ctx.fillRect(this.x + 14, renderY + 4, 16, 1);
    
    // Left ear cup (circular design, positioned away from ear)
    ctx.fillStyle = '#404040';
    // Outer circle approximation with rectangles
    ctx.fillRect(this.x + 6, renderY + 8, 8, 8);
    ctx.fillRect(this.x + 7, renderY + 7, 6, 10);
    ctx.fillRect(this.x + 5, renderY + 9, 10, 6);
    
    // Left ear cup outer rim (circular)
    ctx.fillStyle = '#2a2a2a';
    ctx.fillRect(this.x + 7, renderY + 9, 6, 6);
    ctx.fillRect(this.x + 8, renderY + 8, 4, 8);
    ctx.fillRect(this.x + 6, renderY + 10, 8, 4);
    
    // Left ear cup padding (circular)
    ctx.fillStyle = '#666666';
    ctx.fillRect(this.x + 8, renderY + 10, 4, 4);
    ctx.fillRect(this.x + 9, renderY + 9, 2, 6);
    ctx.fillRect(this.x + 7, renderY + 11, 6, 2);
    
    // Left speaker grille (circular pattern)
    ctx.fillStyle = '#1a1a1a';
    ctx.fillRect(this.x + 9, renderY + 11, 2, 2);
    ctx.fillRect(this.x + 8, renderY + 10, 4, 1);
    ctx.fillRect(this.x + 8, renderY + 13, 4, 1);
    ctx.fillRect(this.x + 8, renderY + 11, 1, 2);
    ctx.fillRect(this.x + 11, renderY + 11, 1, 2);
    
    // Right ear cup (circular design, positioned away from ear)
    ctx.fillStyle = '#404040';
    // Outer circle approximation with rectangles
    ctx.fillRect(this.x + 30, renderY + 8, 8, 8);
    ctx.fillRect(this.x + 31, renderY + 7, 6, 10);
    ctx.fillRect(this.x + 29, renderY + 9, 10, 6);
    
    // Right ear cup outer rim (circular)
    ctx.fillStyle = '#2a2a2a';
    ctx.fillRect(this.x + 31, renderY + 9, 6, 6);
    ctx.fillRect(this.x + 32, renderY + 8, 4, 8);
    ctx.fillRect(this.x + 30, renderY + 10, 8, 4);
    
    // Right ear cup padding (circular)
    ctx.fillStyle = '#666666';
    ctx.fillRect(this.x + 32, renderY + 10, 4, 4);
    ctx.fillRect(this.x + 33, renderY + 9, 2, 6);
    ctx.fillRect(this.x + 31, renderY + 11, 6, 2);
    
    // Right speaker grille (circular pattern)
    ctx.fillStyle = '#1a1a1a';
    ctx.fillRect(this.x + 33, renderY + 11, 2, 2);
    ctx.fillRect(this.x + 32, renderY + 10, 4, 1);
    ctx.fillRect(this.x + 32, renderY + 13, 4, 1);
    ctx.fillRect(this.x + 32, renderY + 11, 1, 2);
    ctx.fillRect(this.x + 35, renderY + 11, 1, 2);
    
    // Adjustment sliders on headband (professional detail)
    ctx.fillStyle = '#666666';
    ctx.fillRect(this.x + 16, renderY + 0, 2, 2);
    ctx.fillRect(this.x + 26, renderY + 0, 2, 2);
    
    if (this.glowIntensity > 0) {
      ctx.restore();
    }
  }

  reset(x: number, y: number) {
    this.x = x;
    this.y = y;
    this.animationTime = 0;
    this.hoverOffset = 0;
    this.glowIntensity = 0;
    
    // Reset particle system
    for (let i = 0; i < this.activeParticleCount; i++) {
      this.returnParticleToPool(this.hoverboardParticles[i]);
    }
    this.activeParticleCount = 0;
  }
}
