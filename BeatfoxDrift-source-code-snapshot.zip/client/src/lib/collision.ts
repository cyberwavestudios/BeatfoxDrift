interface BoundingBox {
  x: number;
  y: number;
  width: number;
  height: number;
}

export class CollisionDetector {
  checkAABB(rect1: BoundingBox, rect2: BoundingBox): boolean {
    return (
      rect1.x < rect2.x + rect2.width &&
      rect1.x + rect1.width > rect2.x &&
      rect1.y < rect2.y + rect2.height &&
      rect1.y + rect1.height > rect2.y
    );
  }

  checkObstacleCollisions(player: BoundingBox, obstacles: BoundingBox[]): boolean {
    // Add small padding to make collision feel fair
    const paddedPlayer = {
      x: player.x + 4,
      y: player.y + 4,
      width: player.width - 8,
      height: player.height - 8
    };

    for (const obstacle of obstacles) {
      if (this.checkAABB(paddedPlayer, obstacle)) {
        return true;
      }
    }
    
    return false;
  }
}
