# Beatfox: Drift — Node app handoff

This package contains the clean source and a locally built `dist` folder. It is not a static-only site: the Express server serves the game. Install dependencies with pnpm, then run `pnpm start` with `NODE_ENV=production` and `PORT` (default 5000). Put a reverse proxy with HTTPS in front of the process. The self-hosted GitHub edition has no password or access-code requirement; do not configure or publish an old access code.

The self-host copy removes the Patreon access-code screen and validation endpoint; the game menu is available immediately. It also uses configurable `PORT` without Replit's `reusePort` setting and declares `nanoid` directly. A pre-removal copy was tested on localhost: the menu unlocked, START DRIFTING produced a running scene, and the score rose. The open-access version passed TypeScript checks and a clean production build, but gameplay/audio and deployment behind your reverse proxy still need owner testing.

Replit development and production `high_scores` exports are in separate restricted local files, not in this ZIP. The inspected server code has no high-score API, so the designer should determine whether those rows are historical or whether another app uses them before importing. The original Replit app remains unchanged.
